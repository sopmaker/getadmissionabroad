<?php
/**
 * Template Name: Success Stories
 * Template for: /success-stories
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>

<section class="page-hero">
  <div class="container">
    <h1>Student <span class="gold">Success Stories</span></h1>
    <p>Every student who works with Prakash receives a strategy built for their specific profile. Here are some of the outcomes.</p>
  </div>
</section>

<!-- Google Reviews -->
<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <h2>What Students Are Saying</h2>
      <p class="subtitle">Verified Google Reviews from students we've worked with.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-2" style="margin-top:2.5rem;">
      <?php
      $testimonials = [
        ['Ankita Dwivedi',     'I had a really smooth experience with this consultancy while applying for my studies abroad. They guided me through every step from university shortlisting to application and documentation. What I appreciated the most was their responsiveness and clarity in communication. Highly recommend to anyone planning to study abroad!'],
        ['Bushra Sayeed Imam', 'The best service you can get for admissions guidance — within one\'s budget and time frame. Not just documentation help but also guidance and suggestions throughout. Finally got into my dream college.'],
        ['Pranjal Sethi',      'Thank you so much for the help. It really means a lot to me — I got my offer letter and I can\'t thank enough. God bless you.'],
        ['Mahima Choudhary',   'I just wanted to express my heartfelt gratitude for all the help in crafting a compelling statement of purpose that helped me get into my dream university. The assistance made a real difference, and I could not have done it without you.'],
      ];
      foreach ($testimonials as $t):
      ?>
      <div class="testimonial-card">
        <div class="testimonial-stars">★★★★★</div>
        <p class="testimonial-text">"<?php echo esc_html($t[1]); ?>"</p>
        <p class="testimonial-name">— <?php echo esc_html($t[0]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Anonymised Stories -->
<section class="section bg-gray">
  <div class="container">
    <div class="section-title center">
      <h2>Student Outcomes</h2>
      <p class="subtitle">Anonymised to protect privacy. Results reflect real engagements.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-2" style="margin-top:2.5rem;">
      <?php
      $stories = [
        [
          'profile' => 'Engineering graduate, CGPA 8.4, internship at a product startup',
          'target'  => 'MS in Computer Science — United States',
          'result'  => 'Admits from 3 universities in the top-20 CS rankings, including a partial scholarship',
          'note'    => 'Profile was initially dismissed as \'average\' by another consultancy. Prakash identified differentiating factors and built a strong research narrative.',
        ],
        [
          'profile' => 'Commerce graduate, work experience at a Big 4 firm (2 years)',
          'target'  => 'MBA / MiM — United Kingdom',
          'result'  => 'Admit from a Russell Group university with a strong scholarship offer',
          'note'    => 'Application built around leadership experience and a clear post-MBA career story — not just GMAT scores.',
        ],
        [
          'profile' => 'Humanities student, interest in public policy and international relations',
          'target'  => 'Master of Public Policy — Canada and UK',
          'result'  => 'Offers from two top programs; accepted Canadian offer with PGWP pathway',
          'note'    => 'Documentation-only engagement — SOP and LORs. Student had been struggling to articulate her research interests before working with Prakash.',
        ],
        [
          'profile' => 'MBBS graduate from a Tier-2 medical college',
          'target'  => 'Public Health / Epidemiology — Australia',
          'result'  => 'Admit from a Group of Eight university',
          'note'    => 'Medical background required a carefully crafted motivation letter connecting clinical experience to public health research goals.',
        ],
      ];
      foreach ($stories as $story):
      ?>
      <div class="story-card">
        <div class="row">
          <p class="row-label">Profile</p>
          <p class="row-value"><?php echo esc_html($story['profile']); ?></p>
        </div>
        <div class="row">
          <p class="row-label">Target</p>
          <p class="row-value"><?php echo esc_html($story['target']); ?></p>
        </div>
        <div class="row">
          <p class="row-label result-label">Result</p>
          <p class="row-value result-value"><?php echo esc_html($story['result']); ?></p>
        </div>
        <p class="note"><?php echo esc_html($story['note']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container" style="text-align:center;">
    <h2>Your Story Could Be Next</h2>
    <p>Book a free call with Prakash and find out what a realistic, well-executed application can achieve for your profile.</p>
    <div class="cta-buttons">
      <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
