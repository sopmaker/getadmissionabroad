<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<!-- Floating Book a Call button -->
<a href="<?php echo esc_url(home_url('/book')); ?>" class="floating-book" aria-label="Book a Free Call">
  <span class="floating-book-tooltip">Book a Free Call</span>
  <span class="floating-book-btn">
    📅
  </span>
</a>

<header class="site-header" id="site-header">
  <!-- Announcement bar -->
  <div class="announce-bar">
    🎓 Free 15-min profile evaluation call —&nbsp;<a href="<?php echo esc_url(home_url('/book')); ?>">Book now, no commitment required</a>
  </div>
  <div class="container">
    <div class="header-inner">
      <!-- Logo -->
      <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
        <img src="http://getadmissionabroad.in/wp-content/uploads/2022/02/logo-remove-bg-transparent.png" alt="Get Admission Abroad" width="160" height="48">
      </a>

      <!-- Desktop nav -->
      <nav class="desktop-nav" aria-label="Primary navigation">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo gaa_is_active('home'); ?>">Home</a>
        <div class="desktop-nav-item has-submenu <?php echo gaa_is_active('services'); ?>">
          <a href="<?php echo esc_url(home_url('/services')); ?>" class="<?php echo gaa_is_active('services'); ?>">Services</a>
          <div class="desktop-submenu" aria-label="Services submenu">
            <a href="<?php echo esc_url(home_url('/profile-building')); ?>" class="<?php echo gaa_is_active('profile-building'); ?>">Profile Building Mentorship</a>
            <a href="<?php echo esc_url(home_url('/admission')); ?>" class="<?php echo gaa_is_active('admission'); ?>">Admission</a>
            <a href="<?php echo esc_url(home_url('/documentation')); ?>" class="<?php echo gaa_is_active('documentation'); ?>">Documentation</a>
            <a href="<?php echo esc_url(home_url('/sop')); ?>" class="<?php echo gaa_is_active('sop'); ?>">SOP</a>
            <a href="<?php echo esc_url(home_url('/lor')); ?>" class="<?php echo gaa_is_active('lor'); ?>">Letter of Recommendation</a>
            <a href="<?php echo esc_url(home_url('/resume')); ?>" class="<?php echo gaa_is_active('resume'); ?>">Resume</a>
            <a href="<?php echo esc_url(home_url('/research-proposal')); ?>" class="<?php echo gaa_is_active('research-proposal'); ?>">Research Proposal</a>
            <a href="<?php echo esc_url(home_url('/scholarship')); ?>" class="<?php echo gaa_is_active('scholarship'); ?>">Scholarship</a>
          </div>
        </div>
        <a href="<?php echo esc_url(home_url('/countries')); ?>" class="<?php echo gaa_is_active('countries'); ?>">Countries</a>
        <a href="<?php echo esc_url(home_url('/success-stories')); ?>" class="<?php echo gaa_is_active('success-stories'); ?>">Success Stories</a>
        <a href="<?php echo esc_url(home_url('/parents')); ?>" class="<?php echo gaa_is_active('parents'); ?>">Parents</a>
        <a href="<?php echo esc_url(home_url('/about-prakash')); ?>" class="<?php echo gaa_is_active('about-prakash'); ?>">About Prakash</a>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="<?php echo gaa_is_active('contact'); ?>">Contact</a>
      </nav>

      <!-- Desktop CTAs -->
      <div class="header-ctas">
        <a href="https://www.instagram.com/prakashabroad/" target="_blank" rel="noopener noreferrer" class="ig-link">
          <svg class="ig-icon" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
          @prakashabroad
        </a>
        <a href="<?php echo esc_url(home_url('/book')); ?>" class="btn btn-gold">Book a Free Call</a>
      </div>

      <!-- Hamburger -->
      <button class="hamburger" id="hamburger" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu">
        <svg id="ham-icon" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
        <svg id="close-icon" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display:none"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>
    </div>
  </div>

  <!-- Mobile menu -->
  <div class="mobile-menu" id="mobile-menu" role="navigation" aria-label="Mobile navigation">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo gaa_is_active('home'); ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/services')); ?>" class="<?php echo gaa_is_active('services'); ?>">Services</a>
    <a href="<?php echo esc_url(home_url('/profile-building')); ?>" class="mobile-sub-link <?php echo gaa_is_active('profile-building'); ?>">› Profile Building Mentorship</a>
    <a href="<?php echo esc_url(home_url('/admission')); ?>" class="mobile-sub-link <?php echo gaa_is_active('admission'); ?>">› Admission</a>
    <a href="<?php echo esc_url(home_url('/documentation')); ?>" class="mobile-sub-link <?php echo gaa_is_active('documentation'); ?>">› Documentation</a>
    <a href="<?php echo esc_url(home_url('/sop')); ?>" class="mobile-sub-link <?php echo gaa_is_active('sop'); ?>">› SOP</a>
    <a href="<?php echo esc_url(home_url('/lor')); ?>" class="mobile-sub-link <?php echo gaa_is_active('lor'); ?>">› Letter of Recommendation</a>
    <a href="<?php echo esc_url(home_url('/resume')); ?>" class="mobile-sub-link <?php echo gaa_is_active('resume'); ?>">› Resume</a>
    <a href="<?php echo esc_url(home_url('/research-proposal')); ?>" class="mobile-sub-link <?php echo gaa_is_active('research-proposal'); ?>">› Research Proposal</a>
    <a href="<?php echo esc_url(home_url('/scholarship')); ?>" class="mobile-sub-link <?php echo gaa_is_active('scholarship'); ?>">› Scholarship</a>
    <a href="<?php echo esc_url(home_url('/countries')); ?>" class="<?php echo gaa_is_active('countries'); ?>">Countries</a>
    <a href="<?php echo esc_url(home_url('/success-stories')); ?>" class="<?php echo gaa_is_active('success-stories'); ?>">Success Stories</a>
    <a href="<?php echo esc_url(home_url('/parents')); ?>" class="<?php echo gaa_is_active('parents'); ?>">Parents</a>
    <a href="<?php echo esc_url(home_url('/about-prakash')); ?>" class="<?php echo gaa_is_active('about-prakash'); ?>">About Prakash</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="<?php echo gaa_is_active('contact'); ?>">Contact</a>
    <div class="mobile-menu-btns">
      <a href="https://www.instagram.com/prakashabroad/" target="_blank" rel="noopener noreferrer" class="btn btn-outline-navy">📷 Follow on Instagram</a>
      <a href="<?php echo esc_url(home_url('/book')); ?>" class="btn btn-gold">Book a Free Call</a>
    </div>
  </div>
</header>

<main class="main-content">
