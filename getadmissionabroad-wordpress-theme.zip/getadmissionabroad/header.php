<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<!-- Floating WhatsApp -->
<a href="https://api.whatsapp.com/send?phone=+918447385389&text=Hi%20Prakash%2C%20I%20want%20to%20know%20more%20about%20study%20abroad%20consulting." target="_blank" rel="noopener noreferrer" class="floating-wa" aria-label="Chat on WhatsApp">
  <span class="tooltip">Chat with Prakash</span>
  <span class="wa-btn">
    <span class="wa-ring"></span>
    <svg viewBox="0 0 32 32"><path d="M16 0C7.163 0 0 7.163 0 16c0 2.822.736 5.476 2.027 7.783L0 32l8.427-2.01A15.938 15.938 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm0 29.333a13.27 13.27 0 01-6.763-1.844l-.485-.287-5.002 1.193 1.217-4.874-.317-.5A13.267 13.267 0 012.667 16C2.667 8.637 8.637 2.667 16 2.667S29.333 8.637 29.333 16 23.363 29.333 16 29.333zm7.273-9.89c-.398-.199-2.355-1.162-2.72-1.295-.365-.133-.631-.199-.897.2-.266.397-1.03 1.294-1.263 1.56-.233.266-.465.3-.863.1-.398-.2-1.681-.62-3.202-1.977-1.184-1.056-1.983-2.361-2.215-2.759-.233-.398-.025-.613.175-.81.18-.178.398-.465.597-.698.2-.233.266-.398.398-.664.133-.266.067-.498-.033-.697-.1-.2-.897-2.162-1.23-2.96-.323-.777-.65-.672-.897-.684l-.764-.013c-.266 0-.697.1-1.063.498-.365.398-1.395 1.362-1.395 3.322s1.428 3.853 1.627 4.119c.2.266 2.81 4.291 6.809 6.017 4 1.726 4 1.152 4.72 1.08.72-.072 2.354-.963 2.688-1.893.333-.93.333-1.727.233-1.893-.1-.166-.366-.266-.764-.465z"/></svg>
  </span>
</a>

<header class="site-header" id="site-header">
  <!-- Announcement bar -->
  <div class="announce-bar">
    🎓 Free 15-min profile evaluation call —&nbsp;<a href="<?php echo esc_url(get_permalink(get_page_by_path('book'))); ?>">Book now, no commitment required</a>
  </div>
  <div class="container">
    <div class="header-inner">
      <!-- Logo -->
      <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
        <img src="http://getadmissionabroad.in/wp-content/uploads/2022/02/logo-remove-bg-transparent.png" alt="Get Admission Abroad" width="160" height="48">
      </a>

      <!-- Desktop nav -->
      <nav class="desktop-nav" aria-label="Primary navigation">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo gaa_is_active('home'); ?>">Home</a>
        <a href="<?php echo esc_url(home_url('/services')); ?>" class="<?php echo gaa_is_active('services'); ?>">Services</a>
        <a href="<?php echo esc_url(home_url('/countries')); ?>" class="<?php echo gaa_is_active('countries'); ?>">Countries</a>
        <a href="<?php echo esc_url(home_url('/success-stories')); ?>" class="<?php echo gaa_is_active('success-stories'); ?>">Success Stories</a>
        <a href="<?php echo esc_url(home_url('/parents')); ?>" class="<?php echo gaa_is_active('parents'); ?>">Parents</a>
        <a href="<?php echo esc_url(home_url('/about-prakash')); ?>" class="<?php echo gaa_is_active('about-prakash'); ?>">About Prakash</a>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="<?php echo gaa_is_active('contact'); ?>">Contact</a>
      </nav>

      <!-- Desktop CTAs -->
      <div class="header-ctas">
        <a href="https://api.whatsapp.com/send?phone=+918447385389" target="_blank" rel="noopener noreferrer" class="wa-link">
          <svg class="wa-icon" viewBox="0 0 32 32"><path d="M16 0C7.163 0 0 7.163 0 16c0 2.822.736 5.476 2.027 7.783L0 32l8.427-2.01A15.938 15.938 0 0016 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm0 29.333a13.27 13.27 0 01-6.763-1.844l-.485-.287-5.002 1.193 1.217-4.874-.317-.5A13.267 13.267 0 012.667 16C2.667 8.637 8.637 2.667 16 2.667S29.333 8.637 29.333 16 23.363 29.333 16 29.333zm7.273-9.89c-.398-.199-2.355-1.162-2.72-1.295-.365-.133-.631-.199-.897.2-.266.397-1.03 1.294-1.263 1.56-.233.266-.465.3-.863.1-.398-.2-1.681-.62-3.202-1.977-1.184-1.056-1.983-2.361-2.215-2.759-.233-.398-.025-.613.175-.81.18-.178.398-.465.597-.698.2-.233.266-.398.398-.664.133-.266.067-.498-.033-.697-.1-.2-.897-2.162-1.23-2.96-.323-.777-.65-.672-.897-.684l-.764-.013c-.266 0-.697.1-1.063.498-.365.398-1.395 1.362-1.395 3.322s1.428 3.853 1.627 4.119c.2.266 2.81 4.291 6.809 6.017 4 1.726 4 1.152 4.72 1.08.72-.072 2.354-.963 2.688-1.893.333-.93.333-1.727.233-1.893-.1-.166-.366-.266-.764-.465z"/></svg>
          WhatsApp
        </a>
        <a href="<?php echo esc_url(home_url('/book')); ?>" class="btn btn-gold">Book a Free Call</a>
      </div>

      <!-- Hamburger -->
      <button class="hamburger" id="hamburger" aria-label="Open menu" aria-expanded="false" aria-controls="mobile-menu">
        <svg id="ham-icon" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
        <svg id="close-icon" width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="display:none"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
      </button>
    </div>
  </div>

  <!-- Mobile menu -->
  <div class="mobile-menu" id="mobile-menu" role="navigation" aria-label="Mobile navigation">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo gaa_is_active('home'); ?>">Home</a>
    <a href="<?php echo esc_url(home_url('/services')); ?>" class="<?php echo gaa_is_active('services'); ?>">Services</a>
    <a href="<?php echo esc_url(home_url('/countries')); ?>" class="<?php echo gaa_is_active('countries'); ?>">Countries</a>
    <a href="<?php echo esc_url(home_url('/success-stories')); ?>" class="<?php echo gaa_is_active('success-stories'); ?>">Success Stories</a>
    <a href="<?php echo esc_url(home_url('/parents')); ?>" class="<?php echo gaa_is_active('parents'); ?>">Parents</a>
    <a href="<?php echo esc_url(home_url('/about-prakash')); ?>" class="<?php echo gaa_is_active('about-prakash'); ?>">About Prakash</a>
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="<?php echo gaa_is_active('contact'); ?>">Contact</a>
    <div class="mobile-menu-btns">
      <a href="https://api.whatsapp.com/send?phone=+918447385389" target="_blank" rel="noopener noreferrer" class="btn btn-outline-navy">💬 WhatsApp Prakash</a>
      <a href="<?php echo esc_url(home_url('/book')); ?>" class="btn btn-gold">Book a Free Call</a>
    </div>
  </div>
</header>

<main class="main-content">
