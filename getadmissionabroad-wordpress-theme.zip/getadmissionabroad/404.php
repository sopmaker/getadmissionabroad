<?php get_header(); ?>
<section style="padding:5rem 0;text-align:center;">
  <div class="container">
    <h1>Page Not Found</h1>
    <p style="margin-top:1rem;color:#6b7280;">Sorry, that page doesn't exist.</p>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-navy" style="margin-top:1.5rem;">← Back to Home</a>
  </div>
</section>
<?php get_footer(); ?>
