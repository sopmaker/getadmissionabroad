<?php
/**
 * Template Name: Services
 * Template for: /services
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>

<section class="page-hero">
  <div class="container">
    <h1>Study Abroad Services, <span class="gold">Profile to Admits</span></h1>
    <p>Every service is personally delivered by Prakash, from your first profile call to the day you submit your final application.</p>
  </div>
</section>

<section class="section bg-white" style="padding-top:2.5rem;padding-bottom:1rem;">
  <div class="container">
    <div class="section-title center">
      <h2>Dedicated Service Pages</h2>
      <p class="subtitle">Explore detailed pages for each major service.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-3" style="margin-top:2rem;">
      <?php
      foreach ([
        ['Profile Building Mentorship', '/profile-building'],
        ['Admission', '/admission'],
        ['Documentation', '/documentation'],
        ['Letter of Recommendation', '/lor'],
        ['Resume', '/resume'],
        ['Research Proposal', '/research-proposal'],
        ['Scholarship', '/scholarship'],
      ] as $service):
      ?>
      <a href="<?php echo esc_url(home_url($service[1])); ?>" class="card" style="padding:1rem 1.25rem;border-radius:1rem;border:1px solid var(--gray-200);display:flex;justify-content:space-between;align-items:center;gap:1rem;">
        <span style="font-size:0.9rem;font-weight:600;color:var(--navy);"><?php echo esc_html($service[0]); ?></span>
        <span style="font-size:1.2rem;color:var(--gold);">→</span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Service 1: Profile Building -->
<section id="profile" class="section bg-white">
  <div class="container">
    <div class="two-col">
      <div>
        <span style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.08em;">Early Stage</span>
        <h2 style="margin-top:0.5rem;">Profile Building Mentorship</h2>
        <p style="margin-top:1rem;color:#4b5563;line-height:1.7;">For students who are 12–18 months away from applications. This is the most impactful phase, when you can actually change your profile, not just document it.</p>
        <ul style="margin-top:1.5rem;display:flex;flex-direction:column;gap:0.75rem;">
          <?php
          $items = [
            'Comprehensive profile evaluation (academics, ECs, work/research)',
            'Gap identification and how to address them',
            'Activity and achievement planning',
            'Building a narrative that connects your past to your future goals',
            'Initial university target range development',
            'Regular check-ins as you execute',
          ];
          foreach ($items as $item):
          ?>
          <li style="display:flex;align-items:flex-start;gap:0.5rem;font-size:0.875rem;color:#374151;">
            <span class="check-gold">✓</span> <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <p style="margin-top:1rem;font-size:0.875rem;color:#6b7280;font-style:italic;">Best started 12–18 months before your application cycle.</p>
      </div>
      <div class="card card-amber" style="align-self:start;">
        <div style="font-size:3rem;margin-bottom:1rem;">🏗️</div>
        <h3 style="margin-bottom:0.5rem;">Who this is for</h3>
        <p style="font-size:0.875rem;color:#4b5563;margin-bottom:1rem;">Students in 11th/12th grade or early undergrad who want to apply to top universities in 1–2 years and want to build the strongest possible profile before doing so.</p>
        <h3 style="margin-bottom:0.5rem;">What you get</h3>
        <p style="font-size:0.875rem;color:#4b5563;">A clear, actionable plan for the months ahead — with Prakash available to guide, review, and adjust as you progress.</p>
      </div>
    </div>
  </div>
</section>

<!-- Service 2: Admissions Strategy -->
<section id="strategy" class="section bg-gray">
  <div class="container">
    <div class="two-col">
      <div class="card card-navy" style="align-self:start;order:2;">
        <div style="font-size:3rem;margin-bottom:1rem;">🎯</div>
        <h3 style="color:var(--gold);margin-bottom:0.5rem;">Core service</h3>
        <p style="color:#d1d5db;font-size:0.875rem;margin-bottom:1rem;">This is the full admissions management service, from shortlisting through final submit.</p>
        <h3 style="color:var(--gold);margin-bottom:0.5rem;">Timeline</h3>
        <p style="color:#d1d5db;font-size:0.875rem;">Typically starts 4–6 months before your first application deadline. Earlier is always better.</p>
      </div>
      <div style="order:1;">
        <span style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.08em;">Core Service</span>
        <h2 style="margin-top:0.5rem;">University Admissions Strategy &amp; Applications</h2>
        <p style="margin-top:1rem;color:#4b5563;line-height:1.7;">Research-backed shortlisting, school-specific positioning, and complete application management — from common app essays to final submission.</p>
        <ul style="margin-top:1.5rem;display:flex;flex-direction:column;gap:0.75rem;">
          <?php
          foreach ([
            'Research-backed university shortlisting (reach/match/safety)',
            'School-specific positioning and narrative development',
            'Common App / UCAS / individual portals managed',
            'Essay strategy and multiple draft reviews',
            'Supplemental essays for each school',
            'Interview preparation',
            'Application status tracking and deadline management',
            'Post-admit decision guidance',
          ] as $item):
          ?>
          <li style="display:flex;align-items:flex-start;gap:0.5rem;font-size:0.875rem;color:#374151;">
            <span class="check-gold">✓</span> <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- Service 3: Documentation -->
<section id="documentation" class="section bg-white">
  <div class="container">
    <div class="two-col">
      <div>
        <span style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.08em;">Also Available Standalone</span>
        <h2 style="margin-top:0.5rem;">Documentation &amp; Storytelling Support</h2>
        <p style="margin-top:1rem;color:#4b5563;line-height:1.7;">Your SOP is often the single most important thing the admissions committee reads. We make sure it tells the right story — authentically, compellingly, and aligned to each school.</p>
        <ul style="margin-top:1.5rem;display:flex;flex-direction:column;gap:0.75rem;">
          <?php
          foreach ([
            'Statement of Purpose (SOP), full drafting and multiple revisions',
            'Personal Statement for UK/other systems',
            'Letter of Recommendation (LOR), strategy + drafts for professors/employers',
            'Resume/CV for academic applications',
            'Research Proposal writing',
            'Scholarship essays and motivation letters',
            'Tailored for each school\'s specific requirements',
          ] as $item):
          ?>
          <li style="display:flex;align-items:flex-start;gap:0.5rem;font-size:0.875rem;color:#374151;">
            <span class="check-gold">✓</span> <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
      <div class="card card-amber" style="align-self:start;">
        <div style="font-size:3rem;margin-bottom:1rem;">📝</div>
        <blockquote style="color:#374151;font-style:italic;font-size:0.875rem;line-height:1.7;">
          "A compelling SOP doesn't just describe what you've done — it explains why you're the right fit for this specific program, at this specific school, right now. That takes real thought, not templates."
        </blockquote>
        <p style="margin-top:0.75rem;font-size:0.75rem;font-weight:700;color:var(--navy);">— Prakash</p>
      </div>
    </div>
  </div>
</section>

<!-- Process Flow -->
<section class="section bg-gray">
  <div class="container">
    <div class="section-title center">
      <h2>How the Process Works</h2>
      <p class="subtitle">From first call to final admit.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="process-steps" style="margin-top:2.5rem;">
      <?php
      foreach ([
        ['01','Free Discovery Call',    '15 minutes with Prakash. You explain your profile and goals. He gives you honest initial feedback.'],
        ['02','Profile Evaluation',     'Detailed assessment of your academics, activities, and goals. Realistic target range identified.'],
        ['03','Strategy & Execution',   'Shortlist finalised, essays written, applications built, with constant guidance at every step.'],
        ['04','Submit & Decide',        'All materials submitted before deadlines. Post-admit guidance to pick the right offer.'],
      ] as $s):
      ?>
      <div class="process-step">
        <div class="step-icon-wrap">
        <div class="step-icon" style="width:3rem;height:3rem;font-size:1.25rem;font-weight:800;color:#ffffff;"><?php echo esc_html($s[0]); ?></div>
        </div>
        <h3><?php echo esc_html($s[1]); ?></h3>
        <p><?php echo esc_html($s[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container" style="text-align:center;">
    <h2>Ready to Start?</h2>
    <p>Book a free 15-minute call with Prakash, no commitment required.</p>
    <div class="cta-buttons">
      <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a>
      <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Get in Touch</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
