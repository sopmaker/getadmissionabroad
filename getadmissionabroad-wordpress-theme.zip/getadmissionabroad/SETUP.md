# Get Admission Abroad — WordPress Theme
## Setup Instructions

### Step 1: Upload the Theme

1. Log into your **WordPress admin** (yoursite.com/wp-admin)
2. Go to **Appearance → Themes → Add New → Upload Theme**
3. Upload `getadmissionabroad.zip`
4. Click **Activate**

---

### Step 2: Create the Pages

Go to **Pages → Add New** and create **one page per row** below.  
**Important:** Set the slug exactly as shown in the table. The theme auto-selects the right template based on slug — so you do NOT need to change the Template dropdown (leave it as "Default Template").

| Page Title       | Slug (URL name)   | Page content |
|-----------------|-------------------|--------------|
| Home            | (set as homepage) | Leave blank  |
| Services        | `services`        | Leave blank  |
| SOP Writing     | `sop`             | Leave blank  |
| Countries       | `countries`       | Leave blank  |
| Success Stories | `success-stories` | Leave blank  |
| Parents         | `parents`         | Leave blank  |
| About Prakash   | `about-prakash`   | Leave blank  |
| Contact         | `contact`         | Leave blank  |
| Book a Session  | `book`            | Leave blank  |

> **How to check/set the slug:** When editing a page in WP admin, the slug is shown below the title field as "Permalink". Click **Edit** next to it and type the exact slug from the table above.

> **Template dropdown:** Leave it on "Default Template" — the theme automatically uses the correct template based on the page slug. No manual selection needed.

> **Tip:** Leave all page content areas blank — the template files handle all the HTML.

---

### Step 3: Set the Home Page

1. Go to **Settings → Reading**
2. Under "Your homepage displays", select **A static page**
3. Set **Homepage** to **"Home"**

---

### Step 4: Configure URLs

1. Go to **Settings → Permalinks**
2. Select **Post name** (e.g. `/sample-post/`)
3. Click **Save Changes**

This ensures `/services`, `/book`, `/contact` etc. work correctly.

---

### Step 5: Set the Admin Email (for booking notifications)

1. Go to **Settings → General**
2. Enter your email address in **Administration Email Address**
3. All booking confirmation emails will go to this address.

---

### Step 6: Configure Contact Form 7 (Homepage form)

The homepage "Get a Free Profile Review" form now supports **Contact Form 7**.

1. Install and activate **Contact Form 7** plugin.
2. Create one form in **Contact → Contact Forms** (fields: name, email, phone, message).
3. In the form's **Mail** tab, keep only admin notification enabled.
4. Make sure any user auto-reply / second mail is disabled.
5. Save. The theme will auto-render the first Contact Form 7 form in the homepage hero card.

> If Contact Form 7 is not installed, the theme uses its built-in fallback form automatically.

---

### Step 7: Email Setup (Optional but recommended)

By default WordPress sends emails using PHP mail, which may end up in spam.  
Install the free plugin **WP Mail SMTP** and connect it to Gmail or Brevo (free tier) for reliable email delivery.

---

### Step 8: View Bookings

All bookings submitted via the Book a Session form are saved to your database.  
View them at **WordPress Admin → Bookings** (appears in the left sidebar).

---

### Troubleshooting

**Inner pages show OLD content / changes not visible after re-uploading theme?**

WordPress will not overwrite an active theme with the same version number. Do a full clean replacement:
1. In WP Admin → **Appearance → Themes**, switch temporarily to a different theme (e.g. Twenty Twenty-Four).
2. Find "Get Admission Abroad" → click **Delete**.
3. Go to **Appearance → Themes → Add New → Upload Theme** → upload the new ZIP → **Activate**.
4. After activating, go to **Settings → Permalinks → Save Changes** once.

If you cannot delete and re-upload, use **Hostinger File Manager** instead:
1. Navigate to `public_html/wp-content/themes/`.
2. Delete the entire `getadmissionabroad` folder.
3. Upload and extract the new ZIP.
4. The theme remains active — just reload any page.

**Pages show the right layout but ignore template changes?**

Your browser or a caching plugin may be serving stale files. Try:
- Hard-reload: **Ctrl + Shift + R** (Windows) / **Cmd + Shift + R** (Mac)
- If you use a caching plugin (WP Super Cache, W3 Total Cache, etc.), go to its settings and click **Flush / Empty Cache**.
- If on Hostinger, check **Hostinger hPanel → Advanced → Cache Manager → Purge Cache**.

**Inner pages (Services, Countries etc.) show 404?**
1. Go to **Settings → Permalinks** and click **Save Changes** (even if nothing changed — this regenerates `.htaccess`).
2. Make sure each page slug matches EXACTLY what's in the table above (`services`, `sop`, `countries`, `success-stories`, `parents`, `about-prakash`, `contact`, `book`). The theme routes by slug.
3. To check a page slug: edit the page in WP Admin, look under the title for "Permalink" and click **Edit** to see/change the slug.
4. After saving permalinks, visit `/services` again.

**How to verify the correct slug for each page:**
| Page | Required slug |
|------|--------------|
| Services | `services` |
| SOP Writing | `sop` |
| Countries | `countries` |
| Success Stories | `success-stories` |
| Parents | `parents` |
| About Prakash | `about-prakash` |
| Contact | `contact` |
| Book a Session | `book` |

**Pages show blank content?** → The slug might not match. Edit the page in WP admin and check the Permalink slug under the page title.

**Images not showing?** → The theme uses external image URLs (Prakash's photo from sop-writer.in). These load from the internet — no upload needed.

**Logo not showing?** → The logo loads from getadmissionabroad.in. If you've moved your domain, re-upload the logo to your Media Library and update the `header.php` img src.

**Emails not sending?** → Install WP Mail SMTP plugin.

**Booking email behavior:** `/book` now sends notification only to the admin email. Students do not receive automatic booking emails.

---

### Pages reference

| URL path         | PHP Template file              |
|------------------|-------------------------------|
| `/`              | `front-page.php`              |
| `/about-prakash` | `page-about-prakash.php`      |
| `/services`      | `page-services.php`           |
| `/sop`           | `page-sop.php`                |
| `/countries`     | `page-countries.php`          |
| `/success-stories`| `page-success-stories.php`   |
| `/parents`       | `page-parents.php`            |
| `/contact`       | `page-contact.php`            |
| `/book`          | `page-book.php`               |
