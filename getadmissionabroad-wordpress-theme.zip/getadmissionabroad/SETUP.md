# Get Admission Abroad — WordPress Theme
## Setup Instructions

### Step 1: Upload the Theme

1. Log into your **WordPress admin** (yoursite.com/wp-admin)
2. Go to **Appearance → Themes → Add New → Upload Theme**
3. Upload `getadmissionabroad.zip`
4. Click **Activate**

---

### Step 2: Create the Pages

Go to **Pages → Add New** and create **one page per row** below.  
Set the **Page Attributes → Template** dropdown as shown.

| Page Title       | Slug              | Template               |
|-----------------|-------------------|------------------------|
| Home            | (homepage)        | Default Template       |
| Services        | services          | Services               |
| Countries       | countries         | Countries              |
| Success Stories | success-stories   | Success Stories        |
| Parents         | parents           | Parents                |
| About Prakash   | about-prakash     | About Prakash          |
| Contact         | contact           | Contact                |
| Book a Session  | book              | Book a Session         |

> **Tip:** Leave the page content blank — the template handles everything.

---

### Step 3: Set the Home Page

1. Go to **Settings → Reading**
2. Under "Your homepage displays", select **A static page**
3. Set **Homepage** to **"Home"**

---

### Step 4: Configure URLs

1. Go to **Settings → Permalinks**
2. Select **Post name** (e.g. `/sample-post/`)
3. Click **Save Changes**

This ensures `/services`, `/book`, `/contact` etc. work correctly.

---

### Step 5: Set the Admin Email (for booking notifications)

1. Go to **Settings → General**
2. Enter your email address in **Administration Email Address**
3. All booking confirmation emails will go to this address.

---

### Step 6: Email Setup (Optional but recommended)

By default WordPress sends emails using PHP mail, which may end up in spam.  
Install the free plugin **WP Mail SMTP** and connect it to Gmail or Brevo (free tier) for reliable email delivery.

---

### Step 7: View Bookings

All bookings submitted via the Book a Session form are saved to your database.  
View them at **WordPress Admin → Bookings** (appears in the left sidebar).

---

### Troubleshooting

**Pages show 404?** → Go to Settings → Permalinks and click Save Changes again.

**Images not showing?** → The theme uses external image URLs (Prakash's photo from sop-writer.in). These load from the internet — no upload needed.

**Logo not showing?** → The logo loads from getadmissionabroad.in. If you've moved your domain, re-upload the logo to your Media Library and update the `header.php` img src.

**Emails not sending?** → Install WP Mail SMTP plugin.

---

### Pages reference

| URL path         | PHP Template file              |
|------------------|-------------------------------|
| `/`              | `front-page.php`              |
| `/about-prakash` | `page-about-prakash.php`      |
| `/services`      | `page-services.php`           |
| `/countries`     | `page-countries.php`          |
| `/success-stories`| `page-success-stories.php`   |
| `/parents`       | `page-parents.php`            |
| `/contact`       | `page-contact.php`            |
| `/book`          | `page-book.php`               |
