<?php
/**
 * Template Name: Documentation Support
 * Template for: /documentation
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>
<section class="page-hero"><div class="container"><h1>Documentation Support</h1><p>Documentation help aligned with each service and application stage.</p></div></section>
<section class="section bg-white"><div class="container"><div class="section-title center"><h2>Documentation support across services</h2><div class="gold-bar"></div></div><div class="grid-3" style="margin-top:2rem;"><?php foreach ([['Profile Building Mentorship','Activity and impact records, milestone narratives'],['Admission','Application document checks and school-wise packaging'],['Documentation','SOP/personal statement structuring and revisions'],['LOR','Professor briefing points for truthful, specific LORs'],['Resume','Professional CV structure and impact-focused bulleting'],['Research Proposal','Structure and clarity support (we do not write proposals)'],['Scholarship','Scholarship essay review with no outcome guarantees']] as $item): ?><div class="card" style="padding:1.25rem;border:1px solid var(--gray-200);"><h3 style="font-size:1rem;margin-bottom:0.35rem;"><?php echo esc_html($item[0]); ?></h3><p style="font-size:0.9rem;color:#6b7280;"><?php echo esc_html($item[1]); ?></p></div><?php endforeach; ?></div></div></section>
<section class="cta-section"><div class="container" style="text-align:center;"><h2>Need help with documentation?</h2><div class="cta-buttons"><a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a><a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Contact Us</a></div></div></section>
<?php get_footer(); ?>
