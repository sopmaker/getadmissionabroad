<?php
/**
 * Template Name: SOP Writing
 * Template for: /sop
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>

<section class="page-hero">
  <div class="container">
    <h1>SOP Guidance by <span class="gold">India's Top SOP Writer</span></h1>
    <p>Get Admission Abroad was founded by Prakash — known for working on 10,000+ SOP and visa cases across admissions, study visas, refusal visas, tourist/visitor visas, family visas, and more.</p>
  </div>
</section>

<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <p class="eyebrow">Founder-Led SOP Practice</p>
      <h2>Why Students Trust Prakash</h2>
      <p class="subtitle">Strategic positioning, authentic storytelling, and clear guidance — not templates.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-3" style="margin-top:2.5rem;">
      <?php
      $highlights = [
        ['🏆', 'Founder-Led Expertise', 'Every SOP is reviewed by Prakash, India’s Top SOP Writer and founder of Get Admission Abroad.'],
        ['📚', '10,000+ Cases Handled', 'Admissions SOPs plus study, refusal, tourist/visitor, and family visa statements.'],
        ['🌍', 'Global Coverage', 'Trusted guidance for US, UK, Canada, Australia, Europe, UAE, and more.'],
      ];
      foreach ($highlights as $h):
      ?>
      <div class="card" style="padding:2rem;border-radius:1.5rem;border:2px solid rgba(201,168,76,0.2);">
        <div style="font-size:2.25rem;margin-bottom:1rem;"><?php echo esc_html($h[0]); ?></div>
        <h3 style="margin-bottom:0.5rem;"><?php echo esc_html($h[1]); ?></h3>
        <p style="color:#6b7280;font-size:0.9rem;"><?php echo esc_html($h[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section bg-gray">
  <div class="container">
    <div class="two-col">
      <div>
        <p style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;">Originality First</p>
        <h2>We Prefer You Write It. We Make It Exceptional.</h2>
        <div style="width:2.5rem;height:4px;background:var(--gold);border-radius:2px;margin:0.75rem 0 1.5rem;"></div>
        <p style="color:#4b5563;line-height:1.7;">The strongest SOPs come from your own voice and story. Our recommendation is simple: you draft your SOP, and Prakash edits, structures, and mentors you to create a compelling final version. This keeps your thought process intact and your originality unquestioned.</p>
        <p style="color:#4b5563;line-height:1.7;margin-top:1rem;">If you’re unsure how to start, we guide you step-by-step — outlining, framing your narrative, and teaching you how to write a convincing SOP that fits each university or visa requirement.</p>
      </div>
      <div class="card card-amber" style="align-self:start;">
        <div style="font-size:2.5rem;margin-bottom:1rem;">✍️</div>
        <h3 style="margin-bottom:0.75rem;">What Mentorship Looks Like</h3>
        <ul style="display:flex;flex-direction:column;gap:0.75rem;">
          <?php
          foreach ([
            'Brainstorming & story discovery sessions',
            'Detailed feedback on clarity and structure',
            'School-specific positioning and fit',
            'Multiple revisions with direct edits',
            'Plagiarism-safe, originality-focused SOPs',
          ] as $item):
          ?>
          <li style="display:flex;align-items:flex-start;gap:0.5rem;font-size:0.875rem;color:#374151;">
            <span class="check-gold">✓</span> <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</section>

<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <h2>Types of SOPs We Handle</h2>
      <p class="subtitle">Admissions, visas, and everything in between.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-3" style="margin-top:2.5rem;">
      <?php
      $sop_types = [
        ['🎓', 'University Admission SOPs', 'MS, MBA, UG, PhD, and specialized program SOPs.'],
        ['🛂', 'Study Visa SOPs', 'Well-structured statements aligned to visa requirements.'],
        ['🚫', 'Refusal Visa SOPs', 'Re-application SOPs that address previous rejection reasons.'],
        ['✈️', 'Tourist & Visitor Visa SOPs', 'Clear travel intent and strong documentation narrative.'],
        ['👨‍👩‍👧', 'Family & Dependent Visas', 'SOPs for spouse, parent, or dependent categories.'],
        ['🏅', 'Scholarship & Motivation Letters', 'Purpose-driven essays for funding and awards.'],
      ];
      foreach ($sop_types as $type):
      ?>
      <div class="card" style="padding:1.75rem;border-radius:1.25rem;border:1px solid var(--gray-200);">
        <div style="font-size:2rem;margin-bottom:0.75rem;"><?php echo esc_html($type[0]); ?></div>
        <h3 style="margin-bottom:0.5rem;"><?php echo esc_html($type[1]); ?></h3>
        <p style="color:#6b7280;font-size:0.85rem;"><?php echo esc_html($type[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section bg-gray">
  <div class="container">
    <div class="section-title center">
      <h2>Countries We Cater</h2>
      <p class="subtitle">Focused on high-competition destinations with nuanced SOP expectations.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-5" style="margin-top:2.5rem;">
      <?php foreach (['🇺🇸 United States','🇬🇧 United Kingdom','🇨🇦 Canada','🇦🇺 Australia','🇩🇪 Germany','🇮🇪 Ireland','🇫🇷 France','🇳🇱 Netherlands','🇸🇬 Singapore','🇦🇪 UAE'] as $country): ?>
      <div class="card" style="padding:0.9rem 1rem;border-radius:1rem;border:1px solid var(--gray-200);text-align:center;font-size:0.85rem;font-weight:600;">
        <?php echo esc_html($country); ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <h2>Our SOP Mentorship Flow</h2>
      <p class="subtitle">A clear process that keeps your voice intact and your story strong.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="process-steps" style="margin-top:3rem;">
      <?php
      $steps = [
        ['🧭', 'Clarity Session', 'We understand your goals, program fit, and story direction.'],
        ['📝', 'Student Draft', 'You write the first version with our structure guidance.'],
        ['🔎', 'Mentor Edits', 'Prakash reviews, restructures, and improves the narrative.'],
        ['✨', 'Final Polish', 'Multiple revisions until the SOP is application-ready.'],
      ];
      foreach ($steps as $i => $s):
      ?>
      <div class="process-step">
        <div class="step-icon-wrap">
          <div class="step-icon"><?php echo esc_html($s[0]); ?></div>
          <span class="step-num"><?php echo esc_html($i + 1); ?></span>
        </div>
        <h3><?php echo esc_html($s[1]); ?></h3>
        <p><?php echo esc_html($s[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="cta-section">
  <div class="container" style="text-align:center;">
    <h2>Ready to Build Your SOP the Right Way?</h2>
    <p>Book a free 15-minute call with Prakash and get clarity on your SOP strategy.</p>
    <div class="cta-buttons">
      <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a>
      <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Ask a Question</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
