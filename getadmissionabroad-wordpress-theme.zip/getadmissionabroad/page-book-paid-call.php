<?php
/**
 * Template Name: Book Paid Strategy Session
 * Template for: /book-paid-call
 */
get_header();
?>

<!-- ═══ SECTION 1 — HERO ════════════════════════════════════════════════ -->
<section class="page-hero" style="min-height:auto;padding:3rem 0;">
  <div class="container">
    <h1 style="font-size:clamp(1.75rem,4vw,2.75rem);font-weight:800;color:#fff;">Book a Paid Strategy Session</h1>
    <p style="margin-top:0.75rem;font-size:1.05rem;color:#d1d5db;max-width:640px;">60–90 minutes of focused, personal guidance from Prakash. Your profile, your goals, your roadmap — built together.</p>

    <!-- Feature strip -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-top:2rem;max-width:600px;">
      <?php
      $features = [
        ['🎯','Full profile deep-dive'],
        ['📋','Written summary sent after the call'],
        ['🔒','Only 4–5 sessions taken per week'],
      ];
      foreach ($features as $f) { ?>
        <div style="display:flex;align-items:center;gap:0.6rem;background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.15);border-radius:10px;padding:0.75rem 1rem;">
          <span style="font-size:1.2rem;flex-shrink:0;"><?php echo $f[0]; ?></span>
          <span style="font-size:0.82rem;font-weight:600;color:#e5e7eb;line-height:1.3;"><?php echo esc_html($f[1]); ?></span>
        </div>
      <?php } ?>
    </div>
  </div>
</section>

<!-- ═══ SECTION 2 — WHAT'S INCLUDED ═══════════════════════════════════ -->
<section class="section" style="padding:4rem 0;background:#f9fafb;">
  <div class="container" style="max-width:760px;">
    <h2 style="font-size:1.5rem;font-weight:800;color:#1a2744;margin-bottom:1.5rem;">What You Get in This Session</h2>
    <ul style="list-style:none;padding:0;display:flex;flex-direction:column;gap:0.75rem;">
      <?php
      $includes = [
        "Honest assessment of your profile's strengths and gaps",
        "Realistic university target range (reach / match / safety)",
        "Country and program recommendations based on your goals",
        "SOP and documentation strategy overview",
        "Clear next steps — whether you continue with Prakash or not",
        "Written summary of the session sent to you within 24 hours",
      ];
      foreach ($includes as $item) { ?>
        <li style="display:flex;align-items:flex-start;gap:0.75rem;font-size:0.95rem;color:#374151;line-height:1.6;">
          <span style="color:#2563eb;font-weight:700;flex-shrink:0;margin-top:0.1rem;">✓</span>
          <?php echo esc_html($item); ?>
        </li>
      <?php } ?>
    </ul>

    <!-- Pull-quote -->
    <blockquote style="margin-top:2rem;border-left:4px solid #2563eb;background:#eff6ff;border-radius:0 12px 12px 0;padding:1.25rem 1.5rem;">
      <p style="font-size:0.95rem;color:#1e40af;line-height:1.7;font-style:italic;">"Unlike the free 15-min call, this session goes deep. By the end, you'll have a clear picture of your profile, your options, and exactly what needs to happen next."</p>
      <footer style="margin-top:0.5rem;font-size:0.85rem;font-weight:700;color:#1a2744;">— Prakash</footer>
    </blockquote>
  </div>
</section>

<!-- ═══ MAIN CARD (Payment + Form) ════════════════════════════════════ -->
<section class="section" style="padding:3rem 0;background:#fff;">
  <div class="container" style="max-width:760px;">
    <div style="background:#fff;border-radius:1.5rem;border:1px solid #e5e7eb;box-shadow:0 4px 20px rgba(0,0,0,0.07);padding:2.5rem;">

      <!-- ─── SECTION 3 — PAYMENT ──────────────────────────────────── -->
      <div id="paid-payment-section">
        <h2 style="font-size:1.25rem;font-weight:800;color:#1a2744;">Step 1: Complete Payment</h2>
        <p style="font-size:0.875rem;color:#6b7280;margin-top:0.25rem;">Session fee: ₹1,999</p>

        <div style="margin-top:1.5rem;text-align:center;border:1.5px solid #e5e7eb;border-radius:16px;padding:2rem 1.5rem;background:#f9fafb;max-width:320px;margin-left:auto;margin-right:auto;">
          <img src="https://getadmissionabroad.in/wp-content/uploads/2026/05/QR-code-for-payment.jpeg" alt="UPI payment QR code" style="width:180px;height:180px;border-radius:12px;display:block;margin:0 auto;">
          <p style="margin-top:1rem;font-size:0.85rem;font-weight:700;color:#1a2744;">UPI ID: <span style="color:#2563eb;user-select:all;">swprakash@axl</span></p>
          <p style="font-size:0.8rem;color:#6b7280;margin-top:0.375rem;">Pay ₹1,999 via any UPI app (GPay, PhonePe, Paytm, etc.)</p>
        </div>
      </div>

      <!-- ─── SECTION 4 — FORM ─────────────────────────────────────── -->
      <div id="paid-form-section" style="margin-top:2.5rem;">
        <h2 style="font-size:1.25rem;font-weight:800;color:#1a2744;">Step 2: Submit Your Details &amp; Schedule the Call</h2>
        <p style="font-size:0.875rem;color:#6b7280;margin-top:0.25rem;">Once payment is done, fill in the form below. Prakash will confirm your slot on WhatsApp.</p>

        <div style="margin-top:1.5rem;display:grid;gap:1rem;grid-template-columns:1fr;">
          <!-- Name -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-name">Full Name *</label>
            <input class="form-input" type="text" id="p-name" placeholder="e.g. Riya Sharma" required>
          </div>
          <!-- Email -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-email">Email Address *</label>
            <input class="form-input" type="email" id="p-email" placeholder="e.g. riya@email.com" required>
          </div>
          <!-- Phone -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-phone">Phone Number (10 digits) *</label>
            <input class="form-input" type="tel" id="p-phone" placeholder="e.g. 9876543210" maxlength="10" required>
          </div>

          <!-- Targeting -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-targeting">What are you targeting? *</label>
            <select class="form-input form-select" id="p-targeting" required>
              <option value="">— Select —</option>
              <option value="Undergraduate (UG)">Undergraduate (UG)</option>
              <option value="Postgraduate / Masters (PG)">Postgraduate / Masters (PG)</option>
              <option value="PhD / Research">PhD / Research</option>
              <option value="Other">Other</option>
              <option value="Not sure yet">Not sure yet</option>
            </select>
          </div>

          <!-- Countries -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label">Which countries are you considering? *</label>
            <div style="display:flex;flex-wrap:wrap;gap:0.625rem;margin-top:0.375rem;">
              <?php
              $countries = [
                'United States 🇺🇸','United Kingdom 🇬🇧','Canada 🇨🇦',
                'Australia 🇦🇺','UAE 🇦🇪','Other','Not decided',
              ];
              foreach ($countries as $c) { ?>
                <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.875rem;cursor:pointer;padding:0.375rem 0.75rem;border:1.5px solid #e5e7eb;border-radius:8px;background:#f9fafb;" class="country-checkbox-label">
                  <input type="checkbox" class="p-country" value="<?php echo esc_attr($c); ?>" style="accent-color:#2563eb;width:14px;height:14px;flex-shrink:0;">
                  <?php echo esc_html($c); ?>
                </label>
              <?php } ?>
            </div>
          </div>

          <!-- Situation -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-msg">Briefly describe your profile and what you want from this session *</label>
            <textarea class="form-textarea" id="p-msg" rows="4" placeholder="e.g. I'm a 3rd year engineering student, 8.5 CGPA, targeting MS in Data Science in the US / UK. I need help understanding my realistic chances and where to focus my efforts." required></textarea>
          </div>

          <!-- Date & Slot heading -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:1rem;font-weight:700;color:#1a2744;">Preferred Date &amp; Time for Your Call *</label>
            <p style="font-size:0.8rem;color:#9ca3af;margin-top:0.25rem;">Calls available 8 AM – 10 PM, 7 days a week. You can schedule from tomorrow onwards.</p>

            <!-- Same-day checkbox -->
            <label style="display:flex;align-items:center;gap:0.5rem;margin-top:0.75rem;font-size:0.875rem;cursor:pointer;padding:0.625rem 0.875rem;border:1.5px solid #e5e7eb;border-radius:10px;background:#f9fafb;">
              <input type="checkbox" id="p-sameday" style="accent-color:#2563eb;width:15px;height:15px;flex-shrink:0;">
              I need a same-day call today (subject to availability)
            </label>
            <div id="p-sameday-note" style="display:none;margin-top:0.5rem;font-size:0.8rem;color:#2563eb;background:#eff6ff;border-radius:8px;padding:0.5rem 0.75rem;border:1px solid #bfdbfe;">
              ℹ️ Same-day calls are subject to Prakash's availability. He'll confirm on WhatsApp as soon as possible.
            </div>
          </div>

          <!-- Date picker -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-date">Select a Date *</label>
            <input class="form-input" type="date" id="p-date" required>
          </div>

          <!-- Time slot -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-slot">Preferred Time Slot *</label>
            <select class="form-input form-select" id="p-slot" required>
              <option value="">— Select a time —</option>
              <?php
              for ($h = 8; $h <= 22; $h++) {
                $h12  = $h > 12 ? $h - 12 : ($h === 12 ? 12 : $h);
                $ampm = $h >= 12 ? 'PM' : 'AM';
                $val  = sprintf('%d:00 %s', $h12, $ampm);
                echo '<option value="' . esc_attr($val) . '">' . esc_html($val) . '</option>';
              }
              ?>
            </select>
          </div>

          <!-- Transaction ID -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-txnid">UPI Transaction ID *</label>
            <input class="form-input" type="text" id="p-txnid" placeholder="Enter the transaction ID from your payment app" required>
            <p style="font-size:0.78rem;color:#9ca3af;margin-top:0.375rem;">You'll find this in your UPI app under recent transactions.</p>
          </div>

          <!-- Referral (optional) -->
          <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" for="p-referral">How did you hear about Prakash? <span style="font-weight:400;color:#9ca3af;">(optional)</span></label>
            <select class="form-input form-select" id="p-referral">
              <option value="">— Select —</option>
              <option value="Instagram (@prakashabroad)">Instagram (@prakashabroad)</option>
              <option value="Google Search">Google Search</option>
              <option value="Referred by a friend">Referred by a friend</option>
              <option value="From the free call">From the free call</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>

        <div id="paid-error" class="form-error" style="display:none;margin-top:1rem;"></div>

        <button type="button" id="paid-submit-btn" onclick="gaaPaidSubmit()" class="btn" style="margin-top:1.5rem;width:100%;justify-content:center;background:#2563eb;color:#fff;font-size:1rem;padding:0.875rem 1.5rem;border-radius:12px;border:none;cursor:pointer;font-weight:700;transition:background 0.2s;">
          Confirm My Session →
        </button>
      </div>

      <!-- ─── SECTION 5 — CONFIRMATION ─────────────────────────────── -->
      <div id="paid-confirmed" style="display:none;padding:3rem 1rem;text-align:center;">
        <div style="font-size:2.5rem;margin-bottom:0.75rem;">✅</div>
        <h3 style="font-size:1.4rem;font-weight:800;color:#1a2744;">Session Request Received!</h3>
        <p id="paid-confirm-msg" style="margin-top:0.75rem;color:#4b5563;line-height:1.7;max-width:520px;margin-left:auto;margin-right:auto;"></p>
        <a href="mailto:getadmissionabroad.in@gmail.com" class="btn btn-navy" style="margin-top:1.5rem;">✉️ Email Prakash</a>
      </div>
    </div>

    <!-- ─── SECTION 6 — REASSURANCE STRIP ─────────────────────────── -->
    <div style="margin-top:2rem;display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1rem;">
      <?php
      $reassurance = [
        ['🔒','Payment is secure','UPI is processed directly through your bank app. No card details stored here.'],
        ['📞','Confirmation within 4 hours','Prakash personally reviews every request.'],
        ['↩️','Full refund if unavailable','If Prakash cannot take your slot — no questions asked.'],
      ];
      foreach ($reassurance as $r) { ?>
        <div style="border:1px solid #e5e7eb;border-radius:12px;padding:1.25rem;background:#f9fafb;">
          <div style="font-size:1.4rem;margin-bottom:0.5rem;"><?php echo $r[0]; ?></div>
          <div style="font-weight:700;font-size:0.85rem;color:#1a2744;margin-bottom:0.25rem;"><?php echo esc_html($r[1]); ?></div>
          <div style="font-size:0.8rem;color:#6b7280;line-height:1.5;"><?php echo esc_html($r[2]); ?></div>
        </div>
      <?php } ?>
    </div>

    <!-- ─── SECTION 7 — MINI FAQ ─────────────────────────────────── -->
    <div style="margin-top:2.5rem;">
      <h2 style="font-size:1.1rem;font-weight:800;color:#1a2744;margin-bottom:1.25rem;">Common Questions</h2>
      <?php
      $faqs = [
        ['Can I reschedule after booking?','Yes. Message Prakash on WhatsApp at least 12 hours before your slot and he\'ll adjust it.'],
        ['What if my preferred time is taken?','Prakash will suggest an alternative time when he confirms on WhatsApp.'],
        ['Is this different from the free call?','Yes. The free 15-min call is a fit check. This session is a full, structured deep-dive where you leave with a written plan.'],
      ];
      foreach ($faqs as $faq) { ?>
        <details style="border:1px solid #e5e7eb;border-radius:12px;margin-bottom:0.75rem;overflow:hidden;">
          <summary style="padding:1rem 1.25rem;font-weight:600;font-size:0.875rem;color:#1a2744;cursor:pointer;background:#f9fafb;list-style:none;display:flex;justify-content:space-between;align-items:center;">
            <?php echo esc_html($faq[0]); ?>
            <span style="flex-shrink:0;margin-left:0.5rem;font-size:1rem;color:#9ca3af;">+</span>
          </summary>
          <p style="padding:1rem 1.25rem;font-size:0.875rem;color:#4b5563;line-height:1.7;margin:0;"><?php echo esc_html($faq[1]); ?></p>
        </details>
      <?php } ?>
    </div>
  </div>
</section>

<script>
(function() {
  // ── Date constraints ────────────────────────────────────────────────
  var todayStr = (function() {
    var now = new Date();
    return now.getFullYear() + '-'
      + String(now.getMonth()+1).padStart(2,'0') + '-'
      + String(now.getDate()).padStart(2,'0');
  })();
  var tomorrowDate = new Date(); tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  var tomorrowStr = tomorrowDate.getFullYear() + '-'
    + String(tomorrowDate.getMonth()+1).padStart(2,'0') + '-'
    + String(tomorrowDate.getDate()).padStart(2,'0');

  var dateInput   = document.getElementById('p-date');
  var samedayCb   = document.getElementById('p-sameday');
  var samedayNote = document.getElementById('p-sameday-note');

  // Default: tomorrow onwards
  dateInput.min = tomorrowStr;

  samedayCb.addEventListener('change', function() {
    if (samedayCb.checked) {
      dateInput.min = todayStr;
      samedayNote.style.display = 'block';
    } else {
      dateInput.min = tomorrowStr;
      samedayNote.style.display = 'none';
      // Clear if today was selected
      if (dateInput.value === todayStr) dateInput.value = '';
    }
  });

  // ── Form submit ─────────────────────────────────────────────────────
  window.gaaPaidSubmit = function() {
    var errEl  = document.getElementById('paid-error');
    errEl.style.display = 'none';

    var name      = document.getElementById('p-name').value.trim();
    var email     = document.getElementById('p-email').value.trim();
    var phone     = document.getElementById('p-phone').value.trim();
    var targeting = document.getElementById('p-targeting').value;
    var msg       = document.getElementById('p-msg').value.trim();
    var date      = document.getElementById('p-date').value;
    var slot      = document.getElementById('p-slot').value;
    var txnid     = document.getElementById('p-txnid').value.trim();
    var referral  = document.getElementById('p-referral').value;

    var countries = [];
    document.querySelectorAll('.p-country:checked').forEach(function(cb){ countries.push(cb.value); });

    if (!name)     { errEl.textContent = 'Please enter your name.'; errEl.style.display='block'; return; }
    if (!email || !/^[^@]+@[^@]+\.[^@]+$/.test(email)) { errEl.textContent = 'Please enter a valid email.'; errEl.style.display='block'; return; }
    if (!/^\d{10}$/.test(phone)) { errEl.textContent = 'Phone must be a 10-digit number.'; errEl.style.display='block'; return; }
    if (!targeting) { errEl.textContent = 'Please select what you are targeting.'; errEl.style.display='block'; return; }
    if (!countries.length) { errEl.textContent = 'Please select at least one country.'; errEl.style.display='block'; return; }
    if (!msg)      { errEl.textContent = 'Please describe your profile and goals.'; errEl.style.display='block'; return; }
    if (!date)     { errEl.textContent = 'Please select a preferred date.'; errEl.style.display='block'; return; }
    if (!slot)     { errEl.textContent = 'Please select a preferred time slot.'; errEl.style.display='block'; return; }
    if (!txnid)    { errEl.textContent = 'Please enter your UPI transaction ID.'; errEl.style.display='block'; return; }

    var btn = document.getElementById('paid-submit-btn');
    btn.textContent = 'Submitting…';
    btn.disabled = true;

    var fd = new FormData();
    fd.append('action',     'gaa_book_paid');
    fd.append('nonce',      (window.gaaData && window.gaaData.nonce) ? window.gaaData.nonce : '');
    fd.append('name',       name);
    fd.append('email',      email);
    fd.append('phone',      phone);
    fd.append('targeting',  targeting);
    countries.forEach(function(c){ fd.append('countries[]', c); });
    fd.append('message',    msg);
    fd.append('date',       date);
    fd.append('slot',       slot);
    fd.append('txnid',      txnid);
    fd.append('referral',   referral);

    fetch(gaaData.ajaxUrl, { method: 'POST', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(data) {
        if (data.success) {
          document.getElementById('paid-payment-section').style.display = 'none';
          document.getElementById('paid-form-section').style.display = 'none';
          var conf = document.getElementById('paid-confirmed');
          conf.style.display = 'block';
          document.getElementById('paid-confirm-msg').textContent =
            'Thank you, ' + name + '. Prakash will review your payment and details and confirm your slot on WhatsApp within a few hours. If you don\'t hear back within 4 hours, email getadmissionabroad.in@gmail.com.';
        } else {
          errEl.textContent = (data.data && data.data.error) ? data.data.error : 'Something went wrong. Please try again.';
          errEl.style.display = 'block';
          btn.textContent = 'Confirm My Session →';
          btn.disabled = false;
        }
      })
      .catch(function() {
        errEl.textContent = 'Network error. Please try again.';
        errEl.style.display = 'block';
        btn.textContent = 'Confirm My Session →';
        btn.disabled = false;
      });
  };
})();
</script>

<?php get_footer(); ?>
