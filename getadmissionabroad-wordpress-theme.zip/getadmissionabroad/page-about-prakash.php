<?php
/**
 * Template Name: About Prakash
 * Template for: /about-prakash
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>

<section class="page-hero">
  <div class="container">
    <div style="display:grid;grid-template-columns:1fr;gap:3.5rem;align-items:center;" class="two-col">
      <div>
        <p style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:1rem;">Founder & Lead Consultant</p>
        <h1>Meet Prakash</h1>
        <div style="margin-top:0.75rem;width:3rem;height:4px;background:var(--gold);border-radius:2px;margin-bottom:1.5rem;"></div>
        <p style="color:#d1d5db;line-height:1.7;">Prakash founded Get Admission Abroad with a clear principle: every student deserves honest, personalised guidance — not a production-line consultancy where they're handed off to a junior and never speak to a senior advisor again.</p>
        <p style="color:#d1d5db;line-height:1.7;margin-top:1rem;">Based in Delhi, he works directly with students and families across India who are targeting universities in the US, UK, Canada, Australia, and UAE. From the first profile call to the last application submission, Prakash is personally involved at every step.</p>
        <div class="credential-badges">
          <?php foreach ([['8+','Years\' Experience'],['500+','Students Guided'],['5','Countries Covered'],['5.0★','Google Rating']] as $c): ?>
          <div class="credential-badge">
            <p class="number"><?php echo esc_html($c[0]); ?></p>
            <p class="label"><?php echo esc_html($c[1]); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
        <div style="margin-top:2rem;display:flex;flex-wrap:wrap;gap:0.75rem;">
          <a href="https://www.instagram.com/prakashabroad/" target="_blank" rel="noopener noreferrer" class="btn btn-outline-white btn-sm">📷 @prakashabroad</a>
          <a href="<?php echo $book_url; ?>" class="btn btn-gold">Book a Call</a>
        </div>
      </div>
      <div class="photo-card-wrap">
        <div class="photo-card">
          <div class="photo-frame">
            <img src="https://sop-writer.in/wp-content/uploads/2026/02/prakash-sop-india.jpg" alt="Prakash — Founder, Get Admission Abroad" loading="eager">
            <div class="photo-overlay"></div>
            <div class="photo-label">
              <p>Prakash</p>
              <p>Founder · Get Admission Abroad, Delhi</p>
            </div>
          </div>
          <div class="photo-badge-bottom">
            <span class="icon">🏆</span>
            <div>
              <p>100% Founder-Led</p>
              <p>No juniors, ever</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Origin Story -->
<section class="section bg-white">
  <div class="container">
    <div class="max-w-3xl mx-auto">
      <p style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;">In His Own Words</p>
      <h2>Why I Started This Practice</h2>
      <div style="width:2.5rem;height:4px;background:var(--gold);border-radius:2px;margin:0.75rem 0 2rem;"></div>
      <div style="display:flex;flex-direction:column;gap:1.25rem;color:#4b5563;line-height:1.7;">
        <p>The study abroad consulting industry in India has a problem: most large consultancies operate like factories. Students pay significant fees, fill out forms, and are assigned to junior counsellors who follow a template. The founder is never involved. The guidance is generic. And outcomes vary wildly.</p>
        <p>I started Get Admission Abroad because I believed there was a better way — and a real need for it. Students applying to competitive programs deserve a consultant who actually understands the nuances of each university's culture, each program's priorities, and each student's unique story.</p>
        <p>That's what I do. It's not scalable in the traditional sense — and that's intentional. I work with a limited number of students at a time so I can genuinely serve each one. Quality over volume, always.</p>
      </div>
    </div>
  </div>
</section>

<!-- My Standards & Process -->
<section class="section bg-gray">
  <div class="container">
    <div class="two-col">
      <div>
        <p style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;">My Commitments</p>
        <h2>My Standards</h2>
        <div style="width:2.5rem;height:4px;background:var(--gold);border-radius:2px;margin:0.75rem 0 2rem;"></div>
        <div style="display:flex;flex-direction:column;gap:1rem;">
          <?php
          $standards = [
            ['Honesty before optimism', 'I will tell you what I genuinely think about your chances — even if it\'s not what you want to hear. That honesty is what makes the guidance valuable.'],
            ['No templates',            'Every SOP, every application strategy, every shortlist is built from scratch. Your story is yours — it shouldn\'t sound like anyone else\'s.'],
            ['You always know where things stand', 'I don\'t believe in black-box consulting. You\'ll always know what we\'re doing, why we\'re doing it, and what\'s coming next.'],
            ['I\'m reachable',          'No ticketing systems, no response windows. If something urgent comes up, you can reach me — and I\'ll respond.'],
          ];
          foreach ($standards as $s):
          ?>
          <div class="standard-item">
            <span class="standard-icon">
              <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
            </span>
            <div>
              <h4><?php echo esc_html($s[0]); ?></h4>
              <p><?php echo esc_html($s[1]); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div>
        <p style="font-size:0.7rem;font-weight:700;color:var(--gold);text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.5rem;">How We Work</p>
        <h2>My Process</h2>
        <div style="width:2.5rem;height:4px;background:var(--gold);border-radius:2px;margin:0.75rem 0 2rem;"></div>
        <div class="numbered-list">
          <?php
          $process = [
            ['Free Discovery Call',  '15 minutes. You explain your situation. I give you my honest initial read.'],
            ['Profile Deep-Dive',    'We go through everything — grades, activities, goals, timeline, target countries.'],
            ['Strategy Document',    'You get a written plan: shortlist, narrative direction, and execution timeline.'],
            ['Execution',            'We build the application together — essays, documents, portal submissions.'],
            ['Decision Support',     'When offers come in, I help you evaluate and decide with clarity.'],
          ];
          foreach ($process as $i => $step):
          ?>
          <div class="numbered-item">
            <span class="num"><?php echo $i+1; ?></span>
            <div>
              <h4><?php echo esc_html($step[0]); ?></h4>
              <p><?php echo esc_html($step[1]); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container">
    <div style="max-width:640px;margin:0 auto;">
      <div class="cta-badge"><span>Free · No Obligation · 15 Minutes</span></div>
      <h2>Let's Talk</h2>
      <p>Book a free 15-minute call and decide for yourself if this is the right fit. No hard sell, no commitment.</p>
      <div class="cta-buttons">
        <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a>
        <a href="https://www.instagram.com/prakashabroad/" target="_blank" rel="noopener noreferrer" class="btn btn-outline-white btn-lg">Follow on Instagram</a>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
