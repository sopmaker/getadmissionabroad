<?php
/**
 * Template Name: Admissions Strategy
 * Template for: /admission
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>
<section class="page-hero"><div class="container"><h1>Admission Strategy &amp; Applications</h1><p>End-to-end support from shortlisting to final submission.</p></div></section>
<section class="section bg-white"><div class="container"><div class="two-col"><div><h2>Core admission support</h2><ul style="margin-top:1rem;display:flex;flex-direction:column;gap:0.65rem;"><?php foreach (['University shortlisting (reach/match/safety)','School-specific application positioning','Essay planning and multi-round reviews','Interview prep and deadline tracking','Post-admit decision support'] as $item): ?><li style="display:flex;gap:0.5rem;"><span class="check-gold">✓</span><?php echo esc_html($item); ?></li><?php endforeach; ?></ul></div><div class="card card-navy" style="align-self:start;"><h3 style="color:var(--gold);">Timeline</h3><p style="color:#d1d5db;">Recommended start: 4–6 months before first deadline.</p></div></div></div></section>
<section class="cta-section"><div class="container" style="text-align:center;"><h2>Plan your admission cycle</h2><div class="cta-buttons"><a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a><a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Contact Us</a></div></div></section>
<?php get_footer(); ?>
