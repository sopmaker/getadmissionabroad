<?php
/**
 * Template Name: Letter of Recommendation
 * Template for: /lor
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>
<section class="page-hero"><div class="container"><h1>Letter of Recommendation (LOR) Support</h1><p>We assist students in guiding professors to write strong, truthful, and specific LORs.</p></div></section>
<section class="section bg-white"><div class="container"><div class="two-col"><div><h2>How we help</h2><ul style="margin-top:1rem;display:flex;flex-direction:column;gap:0.65rem;"><?php foreach (['Recommender selection strategy','Professor briefing notes and talking points','Alignment with target programs','Review for clarity, specificity, and authenticity'] as $item): ?><li style="display:flex;gap:0.5rem;"><span class="check-gold">✓</span><?php echo esc_html($item); ?></li><?php endforeach; ?></ul></div><div class="card card-amber" style="align-self:start;"><h3>Important</h3><p style="color:#4b5563;">We do not fabricate letters. Recommenders write them; we support the process.</p></div></div></div></section>
<section class="cta-section"><div class="container" style="text-align:center;"><h2>Improve your LOR process</h2><div class="cta-buttons"><a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a><a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Contact Us</a></div></div></section>
<?php get_footer(); ?>
