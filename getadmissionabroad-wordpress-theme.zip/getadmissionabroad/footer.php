</main><!-- /.main-content -->

<footer class="site-footer">

  <!-- Pre-footer CTA strip -->
  <div class="footer-cta-strip">
    <div class="container">
      <div class="footer-cta-inner">
        <p>🎓 Ready to start your study abroad journey?</p>
        <div class="footer-cta-btns">
          <a href="<?php echo esc_url(home_url('/book')); ?>" class="btn btn-sm" style="background:#fff;color:#1a2744;font-weight:700;">Book a Free Call</a>
          <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-sm btn-navy">Get in Touch</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Main footer -->
  <div class="footer-main">
    <div class="container">
      <div class="footer-grid">

        <!-- Brand column -->
        <div class="footer-logo-col">
          <a href="<?php echo esc_url(home_url('/')); ?>" class="footer-logo">
            <img src="http://getadmissionabroad.in/wp-content/uploads/2022/02/logo-remove-bg-transparent.png" alt="Get Admission Abroad" width="160" height="48">
          </a>
          <p class="footer-desc">Founder-led study abroad consulting based in Delhi. Prakash personally guides every student, no templates.</p>
          <div class="footer-contacts">
            <a href="https://www.instagram.com/prakashabroad/" target="_blank" rel="noopener noreferrer" class="footer-contact-item">
              <span class="contact-icon" style="background:rgba(236,72,153,0.1)">📷</span>
              @prakashabroad
            </a>
            <a href="mailto:getadmissionabroad.in@gmail.com" class="footer-contact-item">
              <span class="contact-icon" style="background:rgba(59,130,246,0.1)">✉️</span>
              getadmissionabroad.in@gmail.com
            </a>
            <span class="footer-contact-item" style="cursor:default">
              <span class="contact-icon" style="background:#1f2937">📍</span>
              Delhi, India
            </span>
          </div>
        </div>

        <!-- Services -->
        <div>
          <h3 class="footer-heading">Services</h3>
          <ul class="footer-links">
            <li><a href="<?php echo esc_url(home_url('/services#profile')); ?>">Profile Building</a></li>
            <li><a href="<?php echo esc_url(home_url('/services#strategy')); ?>">Admissions Strategy</a></li>
            <li><a href="<?php echo esc_url(home_url('/services#documentation')); ?>">Documentation Help</a></li>
            <li><a href="<?php echo esc_url(home_url('/book')); ?>">Book a Call</a></li>
          </ul>
        </div>

        <!-- Countries -->
        <div>
          <h3 class="footer-heading">Countries</h3>
          <ul class="footer-links">
            <li><a href="<?php echo esc_url(home_url('/countries#us')); ?>">🇺🇸 United States</a></li>
            <li><a href="<?php echo esc_url(home_url('/countries#uk')); ?>">🇬🇧 United Kingdom</a></li>
            <li><a href="<?php echo esc_url(home_url('/countries#canada')); ?>">🇨🇦 Canada</a></li>
            <li><a href="<?php echo esc_url(home_url('/countries#australia')); ?>">🇦🇺 Australia</a></li>
            <li><a href="<?php echo esc_url(home_url('/countries#uae')); ?>">🇦🇪 UAE</a></li>
          </ul>
        </div>

        <!-- Company -->
        <div>
          <h3 class="footer-heading">Company</h3>
          <ul class="footer-links">
            <li><a href="<?php echo esc_url(home_url('/about-prakash')); ?>">About Prakash</a></li>
            <li><a href="<?php echo esc_url(home_url('/success-stories')); ?>">Success Stories</a></li>
            <li><a href="<?php echo esc_url(home_url('/parents')); ?>">For Parents</a></li>
            <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a></li>
          </ul>
        </div>

        <!-- Get Started -->
        <div>
          <h3 class="footer-heading">Get Started</h3>
          <p style="font-size:0.75rem;color:#6b7280;line-height:1.6;margin-bottom:1rem;">15-minute free call. No obligation. Leave with clarity on your options.</p>
          <a href="<?php echo esc_url(home_url('/book')); ?>" class="btn btn-gold btn-sm" style="display:block;text-align:center;">Book Now →</a>
          <a href="<?php echo esc_url(home_url('/contact')); ?>" style="margin-top:0.5rem;display:block;text-align:center;padding:0.5rem;border:1px solid rgba(201,168,76,0.4);color:var(--gold);font-size:0.8rem;font-weight:600;border-radius:8px;transition:background 0.2s;">Get in Touch</a>
        </div>

      </div>

      <div class="footer-bottom">
        <p>© <?php echo date('Y'); ?> Get Admission Abroad. Delhi, India. All rights reserved.</p>
        <p>Founder-led · No templates</p>
      </div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
