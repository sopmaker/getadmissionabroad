<?php
/**
 * Template Name: Countries
 * Template for: /countries
 */
get_header();
$book_url = esc_url(home_url('/book'));

$countries = [
  [
    'id'   => 'us',
    'flag' => '🇺🇸',
    'name' => 'United States',
    'intro'=> 'The US remains the most popular destination for Indian students — offering the broadest range of programs, research opportunities, and post-study work options.',
    'universities' => [
      'Ivy League (Harvard, Princeton, Columbia, Penn, Cornell, Dartmouth, Brown, Yale)',
      'Top Liberal Arts Colleges (Williams, Amherst, Swarthmore)',
      'Strong Research Universities (MIT, Stanford, Caltech, UChicago)',
      'State Flagships (UCLA, Michigan, UNC, Georgia Tech)',
    ],
    'requirements' => [
      'SAT/ACT (optional at many schools, but recommended for competitive profiles)',
      'TOEFL / IELTS for English proficiency',
      'Common App or Coalition App for most undergrad programs',
      'GRE/GMAT for graduate programs',
      'Strong SOPs, LORs, and essays — the differentiating factor',
    ],
    'note' => 'The US has the most complex application system — essays matter enormously. I help students craft a consistent narrative across all their schools so the application reads as one coherent story.',
  ],
  [
    'id'   => 'uk',
    'flag' => '🇬🇧',
    'name' => 'United Kingdom',
    'intro'=> 'The UK offers 3-year undergraduate degrees and 1-year master\'s programs — making it a cost-efficient option with world-class universities.',
    'universities' => [
      'Oxford and Cambridge (highly competitive, subject-specific interviews)',
      'Russell Group: Imperial, LSE, UCL, Edinburgh, Manchester, Bristol, Warwick',
      'Strong arts/design schools: RCA, UAL',
      'Business: LBS, Said, Judge',
    ],
    'requirements' => [
      'UCAS application (centralised) — up to 5 choices for undergrad',
      'Personal Statement (single, not school-specific)',
      'IELTS typically required (6.5–7.5 depending on school)',
      'A-levels / IB / CBSE/ISC conversion for entry requirements',
    ],
    'note' => 'The UK personal statement is a single document that goes to all 5 schools — it needs to be versatile yet focused. Getting this right is crucial, and we work through multiple drafts.',
  ],
  [
    'id'   => 'canada',
    'flag' => '🇨🇦',
    'name' => 'Canada',
    'intro'=> 'Canada combines top-ranked universities, a welcoming immigration pathway (PGWP), and strong quality of life — making it increasingly popular with Indian students.',
    'universities' => [
      'University of Toronto, McGill University',
      'UBC (University of British Columbia)',
      'University of Waterloo (strong for STEM and Co-op)',
      'Queens, McMaster, Western, Simon Fraser',
    ],
    'requirements' => [
      'Academic transcripts with strong grades',
      'IELTS / TOEFL / Duolingo English Test',
      'SOP / Personal Statement (varies by school)',
      'Reference letters',
      'No standardised test (SAT/ACT) required for most undergrad',
    ],
    'note' => 'Canada\'s co-op programs at Waterloo and UBC are exceptional for STEM students. The post-graduation work permit (PGWP) pathway to PR is a major draw — we factor this into university selection.',
  ],
  [
    'id'   => 'australia',
    'flag' => '🇦🇺',
    'name' => 'Australia',
    'intro'=> 'Australia\'s Group of Eight universities rank among the world\'s best, with strong programs in engineering, medicine, business, and the natural sciences.',
    'universities' => [
      'University of Melbourne, ANU (Australian National University)',
      'University of Sydney, UNSW',
      'Monash University, UQ (University of Queensland)',
      'University of Adelaide, University of Western Australia',
    ],
    'requirements' => [
      'Strong academic record',
      'IELTS / TOEFL / PTE Academic',
      'SOP and reference letters',
      'Work experience (for postgrad programs)',
    ],
    'note' => 'Australian universities value research experience and clear career intent. We help students frame their academic journey and goals in a way that resonates with Australian admissions committees.',
  ],
  [
    'id'   => 'uae',
    'flag' => '🇦🇪',
    'name' => 'UAE',
    'intro'=> 'The UAE hosts campuses of some of the world\'s most prestigious universities — including NYU Abu Dhabi and Sorbonne Abu Dhabi — offering a globally recognised education in a tax-free, international environment.',
    'universities' => [
      'NYU Abu Dhabi (highly selective, full scholarships available)',
      'Sorbonne Abu Dhabi',
      'American University in Dubai (AUD)',
      'University of Birmingham Dubai',
      'Heriot-Watt University Dubai',
    ],
    'requirements' => [
      'Strong academic record (especially for NYU Abu Dhabi)',
      'SAT/ACT for some programs',
      'IELTS / TOEFL',
      'Essays and short answers (NYU AD has a unique supplemental)',
    ],
    'note' => 'NYU Abu Dhabi is one of the most selective universities in the world — but also one of the most generous with scholarships. If your profile is strong, it\'s worth a serious application.',
  ],
];
?>

<section class="page-hero">
  <div class="container">
    <h1>Study Abroad Destinations <span class="gold">We Specialise In</span></h1>
    <p>Deep knowledge of universities, admission processes, and what makes strong applications — across five major destinations.</p>
  </div>
</section>

<?php foreach ($countries as $idx => $country): ?>
<section id="<?php echo esc_attr($country['id']); ?>" class="country-section <?php echo $idx % 2 === 0 ? 'bg-white' : 'bg-gray'; ?>">
  <div class="container">
    <div class="country-header">
      <span class="country-flag"><?php echo $country['flag']; ?></span>
      <h2 class="country-name"><?php echo esc_html($country['name']); ?></h2>
    </div>
    <p class="country-intro"><?php echo esc_html($country['intro']); ?></p>
    <div class="country-grid">
      <div>
        <p class="country-list-head">Key Universities</p>
        <ul class="country-list">
          <?php foreach ($country['universities'] as $uni): ?>
          <li><span class="arrow-gold">→</span> <?php echo esc_html($uni); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <div>
        <p class="country-list-head">Key Requirements</p>
        <ul class="country-list">
          <?php foreach ($country['requirements'] as $req): ?>
          <li><span class="check-gold">✓</span> <?php echo esc_html($req); ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <div class="prakash-note">
        <h4>Prakash's Note</h4>
        <p>"<?php echo esc_html($country['note']); ?>"</p>
      </div>
    </div>
  </div>
</section>
<?php endforeach; ?>

<section class="cta-section">
  <div class="container" style="text-align:center;">
    <h2>Not Sure Which Country Is Right for You?</h2>
    <p>Book a free call with Prakash. He'll help you evaluate your options based on your profile, goals, and budget — honestly.</p>
    <div class="cta-buttons">
      <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
