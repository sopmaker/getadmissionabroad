<?php
/**
 * Template Name: Profile Building Mentorship
 * Template for: /profile-building
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>
<section class="page-hero"><div class="container"><h1>Profile Building Mentorship</h1><p>Start early with founder-led guidance to build a strong profile before applications begin.</p></div></section>
<section class="section bg-white"><div class="container"><div class="two-col"><div><h2>What we help with</h2><ul style="margin-top:1rem;display:flex;flex-direction:column;gap:0.65rem;"><?php foreach (['Profile audit and gap analysis','Roadmap for academics, ECs, projects, and impact','Narrative planning for future applications','Periodic check-ins and progress reviews'] as $item): ?><li style="display:flex;gap:0.5rem;"><span class="check-gold">✓</span><?php echo esc_html($item); ?></li><?php endforeach; ?></ul></div><div class="card card-amber" style="align-self:start;"><h3>Best time to start</h3><p style="color:#4b5563;">Ideally 12–18 months before your target intake.</p></div></div></div></section>
<section class="cta-section"><div class="container" style="text-align:center;"><h2>Ready to start?</h2><div class="cta-buttons"><a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a><a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Contact Us</a></div></div></section>
<?php get_footer(); ?>
