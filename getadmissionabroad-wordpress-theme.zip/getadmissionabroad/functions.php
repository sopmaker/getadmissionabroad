<?php
/**
 * Get Admission Abroad – functions.php
 */

// ─── SLUG-BASED TEMPLATE ROUTING ─────────────────────────
// Uses template_include (runs after the query is resolved) with
// get_queried_object_id() — more reliable than page_template + get_post().
// Explicit slug map avoids any file-system guessing.
add_filter('template_include', function ($template) {
    if (!is_page()) {
        return $template;
    }
    $slug_map = [
        'services'          => 'page-services.php',
        'profile-building'  => 'page-profile-building.php',
        'admission'         => 'page-admission.php',
        'documentation'     => 'page-documentation.php',
        'lor'               => 'page-lor.php',
        'resume'            => 'page-resume.php',
        'research-proposal' => 'page-research-proposal.php',
        'scholarship'       => 'page-scholarship.php',
        'sop'               => 'page-sop.php',
        'countries'         => 'page-countries.php',
        'success-stories'   => 'page-success-stories.php',
        'parents'           => 'page-parents.php',
        'about-prakash'     => 'page-about-prakash.php',
        'contact'           => 'page-contact.php',
        'book'              => 'page-book.php',
        'book-paid-call'    => 'page-book-paid-call.php',
    ];
    $slug = get_post_field('post_name', get_queried_object_id());
    if (isset($slug_map[$slug])) {
        $custom = locate_template($slug_map[$slug]);
        if ($custom) {
            return $custom;
        }
    }
    return $template;
});

// Theme setup
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
    register_nav_menus(['primary' => 'Primary Navigation']);
});

// Enqueue assets
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('gaa-style', get_stylesheet_uri(), [], '1.1');
    wp_enqueue_script('gaa-main', get_template_directory_uri() . '/js/main.js', [], '1.1', true);
    // Pass booking nonce to JS
    wp_localize_script('gaa-main', 'gaaData', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('gaa_booking_nonce'),
    ]);
});

function gaa_render_cf7_form(string $context = 'default'): string {
    if (!shortcode_exists('contact-form-7')) {
        return '';
    }

    $context = sanitize_key($context);
    $known_ids = [
        'hero' => 4004693,
    ];
    if (isset($known_ids[$context]) && $known_ids[$context] > 0) {
        return do_shortcode('[contact-form-7 id="' . (int) $known_ids[$context] . '"]');
    }

    $configured_id = (int) apply_filters('gaa_cf7_form_id', 0, $context);
    if ($configured_id > 0) {
        return do_shortcode('[contact-form-7 id="' . $configured_id . '"]');
    }

    if (!class_exists('WPCF7_ContactForm')) {
        return '';
    }

    $forms = WPCF7_ContactForm::find(['posts_per_page' => 1]);
    if (empty($forms)) {
        return '';
    }

    return do_shortcode('[contact-form-7 id="' . (int) $forms[0]->id() . '"]');
}

function gaa_ensure_booking_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table_free = $wpdb->prefix . 'gaa_bookings';
    $sql_free = "CREATE TABLE IF NOT EXISTS {$table_free} (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        name varchar(200) NOT NULL,
        email varchar(200) NOT NULL,
        phone varchar(20) NOT NULL,
        booking_date date NOT NULL,
        slot varchar(20) NOT NULL,
        message text,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) {$charset};";

    $table_paid = $wpdb->prefix . 'gaa_paid_bookings';
    $sql_paid = "CREATE TABLE IF NOT EXISTS {$table_paid} (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        name varchar(200) NOT NULL,
        email varchar(200) NOT NULL,
        phone varchar(20) NOT NULL,
        targeting varchar(100),
        countries text,
        booking_date date NOT NULL,
        slot varchar(20) NOT NULL,
        txnid varchar(200) NOT NULL,
        referral varchar(200),
        message text,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) {$charset};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql_free);
    dbDelta($sql_paid);
}

// ─── BOOKING FORM HANDLER ────────────────────────────────
add_action('wp_ajax_gaa_book',        'gaa_handle_booking');
add_action('wp_ajax_nopriv_gaa_book', 'gaa_handle_booking');
add_action('wp_ajax_gaa_booking_nonce',        'gaa_get_booking_nonce');
add_action('wp_ajax_nopriv_gaa_booking_nonce', 'gaa_get_booking_nonce');

function gaa_get_booking_nonce() {
    wp_send_json_success(['nonce' => wp_create_nonce('gaa_booking_nonce')]);
}

function gaa_handle_booking() {
    if (!check_ajax_referer('gaa_booking_nonce', 'nonce', false)) {
        wp_send_json_error(['error' => 'Security check failed. Please refresh and try again.']);
    }

    $name    = sanitize_text_field($_POST['name'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');
    $date    = sanitize_text_field($_POST['date'] ?? '');
    $slot    = sanitize_text_field($_POST['slot'] ?? '');

    if (!$name || !$email || !$phone || !$date || !$slot) {
        wp_send_json_error(['error' => 'Please fill in all required fields.']);
    }
    if (!is_email($email)) {
        wp_send_json_error(['error' => 'Please enter a valid email address.']);
    }
    if (!preg_match('/^\d{10}$/', $phone)) {
        wp_send_json_error(['error' => 'Phone must be a 10-digit number.']);
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) || !$slot) {
        wp_send_json_error(['error' => 'Please select a valid date and time slot.']);
    }

    gaa_ensure_booking_tables();
    global $wpdb;
    $table = $wpdb->prefix . 'gaa_bookings';
    $inserted = $wpdb->insert($table, [
        'name'         => $name,
        'email'        => $email,
        'phone'        => $phone,
        'booking_date' => $date,
        'slot'         => $slot,
        'message'      => $message,
        'created_at'   => current_time('mysql'),
    ]);
    if ($inserted === false) {
        wp_send_json_error(['error' => 'Could not save your booking. Please try again.']);
    }

    $admin_email  = get_option('admin_email');
    $to_admin     = $admin_email;
    $subject_admin = "New Booking: {$name} — {$date} at {$slot}";
    $body_admin   = "New booking received:\n\nName:    {$name}\nEmail:   {$email}\nPhone:   {$phone}\nDate:    {$date}\nTime:    {$slot} IST\nMessage: {$message}";
    wp_mail($to_admin, $subject_admin, $body_admin, ['Reply-To: ' . $email]);

    wp_send_json_success(['message' => 'Booking confirmed!']);
}

// ─── CONTACT FORM HANDLER ────────────────────────────────
// Old WhatsApp contact action kept for backwards compat but no longer used
add_action('wp_ajax_gaa_contact',        'gaa_handle_contact');
add_action('wp_ajax_nopriv_gaa_contact', 'gaa_handle_contact');

function gaa_handle_contact() {
    if (!check_ajax_referer('gaa_booking_nonce', 'nonce', false)) {
        wp_send_json_error(['error' => 'Security check failed. Please refresh and try again.']);
    }
    wp_send_json_success([]);
}

// ─── EMAIL CONTACT FORM HANDLER ─────────────────────────
add_action('wp_ajax_gaa_contact_email',        'gaa_handle_contact_email');
add_action('wp_ajax_nopriv_gaa_contact_email', 'gaa_handle_contact_email');

function gaa_handle_contact_email() {
    if (!check_ajax_referer('gaa_booking_nonce', 'nonce', false)) {
        wp_send_json_error(['error' => 'Security check failed. Please refresh and try again.']);
    }

    $name    = sanitize_text_field($_POST['name'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (!$name || !$message) {
        wp_send_json_error(['error' => 'Please fill in all required fields.']);
    }
    if (!is_email($email)) {
        wp_send_json_error(['error' => 'Please enter a valid email address.']);
    }

    $admin_email  = get_option('admin_email');
    $subject      = "New Contact Message from {$name}";
    $body         = "New contact message:\n\nName:    {$name}\nEmail:   {$email}\nPhone:   {$phone}\nMessage: {$message}";
    wp_mail($admin_email, $subject, $body, ['Reply-To: ' . $email]);

    wp_send_json_success(['message' => 'Message sent!']);
}

// ─── PAID SESSION BOOKING HANDLER ───────────────────────
add_action('wp_ajax_gaa_book_paid',        'gaa_handle_paid_booking');
add_action('wp_ajax_nopriv_gaa_book_paid', 'gaa_handle_paid_booking');

function gaa_handle_paid_booking() {
    if (!check_ajax_referer('gaa_booking_nonce', 'nonce', false)) {
        wp_send_json_error(['error' => 'Security check failed. Please refresh and try again.']);
    }

    $name      = sanitize_text_field($_POST['name']      ?? '');
    $email     = sanitize_email($_POST['email']           ?? '');
    $phone     = sanitize_text_field($_POST['phone']      ?? '');
    $targeting = sanitize_text_field($_POST['targeting']  ?? '');
    $message   = sanitize_textarea_field($_POST['message'] ?? '');
    $date      = sanitize_text_field($_POST['date']       ?? '');
    $slot      = sanitize_text_field($_POST['slot']       ?? '');
    $txnid     = sanitize_text_field($_POST['txnid']      ?? '');
    $referral  = sanitize_text_field($_POST['referral']   ?? '');

    // Sanitize multi-select countries
    $raw_countries = $_POST['countries'] ?? [];
    $countries = [];
    if (is_array($raw_countries)) {
        foreach ($raw_countries as $c) {
            $countries[] = sanitize_text_field($c);
        }
    }
    $countries_str = implode(', ', $countries);

    if (!$name || !$email || !$phone || !$targeting || !$message || !$date || !$slot || !$txnid) {
        wp_send_json_error(['error' => 'Please fill in all required fields.']);
    }
    if (!is_email($email)) {
        wp_send_json_error(['error' => 'Please enter a valid email address.']);
    }
    if (!preg_match('/^\d{10}$/', $phone)) {
        wp_send_json_error(['error' => 'Phone must be a 10-digit number.']);
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        wp_send_json_error(['error' => 'Please select a valid date.']);
    }

    gaa_ensure_booking_tables();
    global $wpdb;
    $table = $wpdb->prefix . 'gaa_paid_bookings';
    $inserted = $wpdb->insert($table, [
        'name'         => $name,
        'email'        => $email,
        'phone'        => $phone,
        'targeting'    => $targeting,
        'countries'    => $countries_str,
        'booking_date' => $date,
        'slot'         => $slot,
        'txnid'        => $txnid,
        'referral'     => $referral,
        'message'      => $message,
        'created_at'   => current_time('mysql'),
    ]);
    if ($inserted === false) {
        wp_send_json_error(['error' => 'Could not save your session request. Please try again.']);
    }

    $admin_email   = get_option('admin_email');
    $subject_admin = "New Paid Session: {$name} — {$date} at {$slot}";
    $body_admin    = "New paid strategy session request:\n\n"
                   . "Name:      {$name}\n"
                   . "Email:     {$email}\n"
                   . "Phone:     {$phone}\n"
                   . "Targeting: {$targeting}\n"
                   . "Countries: {$countries_str}\n"
                   . "Date:      {$date}\n"
                   . "Time:      {$slot}\n"
                   . "TXN ID:    {$txnid}\n"
                   . "Referral:  {$referral}\n\n"
                   . "Profile / Goals:\n{$message}";
    wp_mail($admin_email, $subject_admin, $body_admin, ['Reply-To: ' . $email]);

    wp_send_json_success(['message' => 'Session request received!']);
}

// ─── CREATE BOOKINGS TABLE ON THEME ACTIVATION ──────────
add_action('after_switch_theme', function () {
    gaa_ensure_booking_tables();
});

// ─── ADMIN: VIEW BOOKINGS ────────────────────────────────
add_action('admin_menu', function () {
    add_menu_page('Bookings', 'Bookings', 'manage_options', 'gaa-bookings', 'gaa_bookings_page', 'dashicons-calendar-alt', 25);
    add_submenu_page('gaa-bookings', 'Free Call Bookings', 'Free Calls', 'manage_options', 'gaa-bookings', 'gaa_bookings_page');
    add_submenu_page('gaa-bookings', 'Paid Session Bookings', 'Paid Sessions', 'manage_options', 'gaa-paid-bookings', 'gaa_paid_bookings_page');
});

function gaa_bookings_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'gaa_bookings';
    $bookings = $wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC");
    echo '<div class="wrap"><h1>Bookings</h1>';
    if (!$bookings) {
        echo '<p>No bookings yet.</p></div>';
        return;
    }
    echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Date</th><th>Slot</th><th>Message</th><th>Submitted</th></tr></thead><tbody>';
    foreach ($bookings as $b) {
        echo '<tr>';
        echo '<td>' . esc_html($b->name) . '</td>';
        echo '<td>' . esc_html($b->email) . '</td>';
        echo '<td>' . esc_html($b->phone) . '</td>';
        echo '<td>' . esc_html($b->booking_date) . '</td>';
        echo '<td>' . esc_html($b->slot) . '</td>';
        echo '<td>' . esc_html($b->message) . '</td>';
        echo '<td>' . esc_html($b->created_at) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

function gaa_paid_bookings_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'gaa_paid_bookings';
    $bookings = $wpdb->get_results("SELECT * FROM {$table} ORDER BY created_at DESC");
    echo '<div class="wrap"><h1>Paid Session Bookings</h1>';
    if (!$bookings) {
        echo '<p>No paid session bookings yet.</p></div>';
        return;
    }
    echo '<table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Targeting</th><th>Countries</th><th>Date</th><th>Slot</th><th>TXN ID</th><th>Referral</th><th>Message</th><th>Submitted</th></tr></thead><tbody>';
    foreach ($bookings as $b) {
        echo '<tr>';
        echo '<td>' . esc_html($b->name)         . '</td>';
        echo '<td>' . esc_html($b->email)        . '</td>';
        echo '<td>' . esc_html($b->phone)        . '</td>';
        echo '<td>' . esc_html($b->targeting)    . '</td>';
        echo '<td>' . esc_html($b->countries)    . '</td>';
        echo '<td>' . esc_html($b->booking_date) . '</td>';
        echo '<td>' . esc_html($b->slot)         . '</td>';
        echo '<td>' . esc_html($b->txnid)        . '</td>';
        echo '<td>' . esc_html($b->referral)     . '</td>';
        echo '<td>' . esc_html($b->message)      . '</td>';
        echo '<td>' . esc_html($b->created_at)   . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

// ─── HELPER: Active nav link ─────────────────────────────
function gaa_is_active(string $slug): string {
    $service_slugs = ['services', 'profile-building', 'admission', 'documentation', 'sop', 'lor', 'resume', 'research-proposal', 'scholarship'];
    if ($slug === 'home' && is_front_page()) return 'active';
    if ($slug === 'services' && is_page($service_slugs)) return 'active';
    if ($slug !== 'home' && is_page($slug)) return 'active';
    return '';
}
