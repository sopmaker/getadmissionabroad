<?php
/**
 * page.php — Generic page fallback with automatic slug-based routing.
 *
 * WordPress template hierarchy already resolves page-{slug}.php automatically,
 * but this file acts as an extra safety net: if a page slug matches one of the
 * known templates, it includes that template directly. Otherwise it renders
 * standard page content so every page at least displays something.
 */

$slug     = get_post_field('post_name', get_post());
$template = locate_template('page-' . $slug . '.php');

if ($template) {
    // Load the slug-matched template (e.g. page-services.php for /services)
    include $template;
    return; // stop here — the included file calls get_header/get_footer itself
}

// Fallback: render any WordPress page content
get_header();
?>
<section style="padding:4rem 0;min-height:60vh;">
  <div class="container">
    <?php if (have_posts()): while (have_posts()): the_post(); ?>
      <h1 style="margin-bottom:1.5rem;"><?php the_title(); ?></h1>
      <div class="entry-content"><?php the_content(); ?></div>
    <?php endwhile; else: ?>
      <h1>Page Not Found</h1>
      <p style="margin-top:1rem;color:#6b7280;">The page you're looking for doesn't exist.</p>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-navy" style="margin-top:1.5rem;">← Back to Home</a>
    <?php endif; ?>
  </div>
</section>
<?php
get_footer();
