<?php
/**
 * Fallback index template — redirects to home.
 * WordPress requires index.php to exist.
 */
get_header();
?>
<section style="padding:5rem 0;text-align:center;">
  <div class="container">
    <?php if (have_posts()): while (have_posts()): the_post(); ?>
      <h1><?php the_title(); ?></h1>
      <div style="margin-top:1.5rem;"><?php the_content(); ?></div>
    <?php endwhile; else: ?>
      <h1>Page Not Found</h1>
      <p style="margin-top:1rem;color:#6b7280;">The page you're looking for doesn't exist.</p>
      <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-navy" style="margin-top:1.5rem;">← Back to Home</a>
    <?php endif; ?>
  </div>
</section>
<?php get_footer(); ?>
