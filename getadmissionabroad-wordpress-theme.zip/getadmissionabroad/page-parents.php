<?php
/**
 * Template Name: Parents
 * Template for: /parents
 */
get_header();
$book_url = esc_url(home_url('/book'));
$contact_url = esc_url(home_url('/contact'));
?>

<section class="page-hero">
  <div class="container">
    <h1>For Parents: <span class="gold">A Transparent, Trustworthy Process</span></h1>
    <p>We understand that sending your child abroad is one of the most significant decisions your family will make. Here's exactly how we approach it.</p>
  </div>
</section>

<!-- What We Do -->
<section class="section bg-white">
  <div class="container">
    <div class="two-col">
      <div>
        <div class="section-title">
          <h2>What We Do</h2>
          <div class="gold-bar"></div>
        </div>
        <p style="color:#4b5563;line-height:1.7;margin-top:1rem;">Get Admission Abroad is a founder-led consulting practice. Every student is personally guided by Prakash — from the first call to the final admit. There are no junior counsellors, no handoffs, and no one-size-fits-all plans.</p>
        <ul style="margin-top:1.5rem;display:flex;flex-direction:column;gap:0.75rem;">
          <?php
          foreach ([
            'Profile evaluation and honest assessment of realistic options',
            'University shortlisting based on fit, not just rankings',
            'Full application strategy and execution',
            'SOP, LOR, and all documentation — crafted personally',
            'Deadline management and submission tracking',
            'Post-admit guidance for final decisions',
          ] as $item):
          ?>
          <li style="display:flex;align-items:flex-start;gap:0.5rem;font-size:0.875rem;color:#374151;">
            <span class="check-gold">✓</span> <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
      </div>
      <div style="display:flex;flex-direction:column;gap:1rem;">
        <?php
        $cards = [
          ['📊','Timeline Clarity',    'You get a month-by-month plan from the start. Every milestone, every deadline is visible and tracked.'],
          ['💰','Cost Transparency',   'Fees are discussed and agreed upon upfront. No surprise add-ons. No vague \'packages\' — just clear scope and clear pricing.'],
          ['🤝','Ethical Approach',    'We don\'t make promises we can\'t keep. We won\'t oversell reach schools or dismiss reasonable targets. Your child\'s long-term success matters more than our short-term business.'],
          ['📲','Direct Access',       'You can reach Prakash directly at any time — by email or phone. Not a helpdesk. Not a chatbot.'],
        ];
        foreach ($cards as $c):
        ?>
        <div class="info-card">
          <span class="ic-icon"><?php echo $c[0]; ?></span>
          <div>
            <h4><?php echo esc_html($c[1]); ?></h4>
            <p><?php echo esc_html($c[2]); ?></p>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- Note from Prakash -->
<section class="section bg-amber-light">
  <div class="container">
    <div class="quote-block">
      <span class="icon">💬</span>
      <blockquote>"I started this practice because I saw how much anxiety and confusion the study abroad process creates for families — especially when a consultant is vague, unreachable, or oversells outcomes. My goal is the opposite: you should always know exactly where things stand, what I'm doing, and why. That's the standard I hold myself to with every family."</blockquote>
      <p class="author">— Prakash, Founder</p>
    </div>
  </div>
</section>

<!-- FAQ for Parents -->
<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <h2>Questions Parents Ask</h2>
      <div class="gold-bar"></div>
    </div>
    <div class="faq-list" style="margin-top:2.5rem;">
      <?php
      $faqs = [
        ['How do we know the process is moving forward?',
         'Prakash provides weekly updates and maintains a shared task tracker. You always know what\'s been done, what\'s next, and what\'s due.'],
        ['What if my child\'s profile isn\'t strong enough for top universities?',
         'We give honest assessments from day one. We build a balanced list: some aspirational schools, some strong matches, and some safe admits. The goal is a good outcome — not false hope.'],
        ['Can we speak directly with Prakash?',
         'Absolutely. Prakash is not a brand behind a team — he\'s a founder who works directly with every family. You can call or email him at any point.'],
        ['How are fees structured?',
         'Fees vary by the scope of service and are clearly discussed upfront. There are no hidden charges. Everything is documented before we begin.'],
        ['What if my child is in 11th grade — is it too early to start?',
         'Not at all. Starting early is actually ideal. The earlier we begin, the more we can do to strengthen the profile before applications open.'],
        ['Do you guarantee admission?',
         'No. Anyone who guarantees admission is misleading you. What we guarantee is an honest, thorough, professionally executed application — one that gives your child the best realistic chance.'],
      ];
      foreach ($faqs as $faq):
      ?>
      <div class="faq-item">
        <button class="faq-q" aria-expanded="false">
          <?php echo esc_html($faq[0]); ?>
          <svg class="chevron" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <div class="faq-a"><?php echo esc_html($faq[1]); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="cta-section">
  <div class="container" style="text-align:center;">
    <h2>Let's Have a Conversation</h2>
    <p>Book a free 15-minute call with Prakash — with or without your child. Ask everything you need to feel comfortable about the process.</p>
    <div class="cta-buttons">
      <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a>
      <a href="<?php echo $contact_url; ?>" class="btn btn-outline-white btn-lg">Get in Touch →</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
