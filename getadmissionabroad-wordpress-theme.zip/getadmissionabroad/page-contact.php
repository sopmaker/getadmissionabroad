<?php
/**
 * Template Name: Contact
 * Template for: /contact
 */
get_header();
$wa_url        = 'https://api.whatsapp.com/send?phone=+918447385389';
$instagram_url = 'https://www.instagram.com/sopwriterprakash/';
?>

<section class="page-hero">
  <div class="container">
    <h1>Get in <span class="gold">Touch</span></h1>
    <p>The fastest way to reach Prakash is WhatsApp. He responds to every serious inquiry personally.</p>
  </div>
</section>

<section class="section bg-white">
  <div class="container">
    <div class="two-col">
      <!-- Contact Details -->
      <div>
        <h2 style="margin-bottom:1.5rem;">Contact Details</h2>
        <div style="display:flex;flex-direction:column;gap:1rem;">

          <a href="<?php echo $wa_url; ?>" target="_blank" rel="noopener noreferrer" class="contact-card whatsapp">
            <span class="contact-icon-big">💬</span>
            <div>
              <p class="contact-name">WhatsApp</p>
              <p class="contact-val">+91 8447385389</p>
            </div>
          </a>

          <a href="<?php echo $instagram_url; ?>" target="_blank" rel="noopener noreferrer" class="contact-card instagram">
            <span class="contact-icon-big">📷</span>
            <div>
              <p class="contact-name">Instagram</p>
              <p class="contact-val">@sopwriterprakash</p>
            </div>
          </a>

          <a href="mailto:getadmissionabroad.in@gmail.com" class="contact-card email">
            <span class="contact-icon-big">✉️</span>
            <div>
              <p class="contact-name">Email</p>
              <p class="contact-val">getadmissionabroad.in@gmail.com</p>
            </div>
          </a>

          <div class="contact-card address">
            <span class="contact-icon-big">📍</span>
            <div>
              <p class="contact-name">Location</p>
              <p class="contact-val">Delhi, India</p>
            </div>
          </div>

        </div>
      </div>

      <!-- Quick WhatsApp Message form -->
      <div>
        <h2 style="margin-bottom:0.75rem;">Quick Message</h2>
        <p style="font-size:0.875rem;color:#6b7280;margin-bottom:1.5rem;">Fill in your details below and we'll open WhatsApp with your message pre-filled — so Prakash gets full context right away.</p>

        <div id="quick-contact-form">
          <div class="form-group">
            <label class="form-label" for="qc-name">Your Name *</label>
            <input class="form-input" type="text" id="qc-name" placeholder="e.g. Riya Sharma" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="qc-msg">Your Message *</label>
            <textarea class="form-textarea" id="qc-msg" rows="5" placeholder="e.g. I'm a final year engineering student looking to apply for MS in CS in the US. Can we discuss my profile?" required></textarea>
          </div>
          <button type="button" onclick="gaaOpenWhatsApp()" class="btn btn-green" style="width:100%;justify-content:center;padding:0.875rem;">
            💬 Open WhatsApp with Message
          </button>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
function gaaOpenWhatsApp() {
  var name = document.getElementById('qc-name').value.trim();
  var msg  = document.getElementById('qc-msg').value.trim();
  if (!name || !msg) { alert('Please fill in your name and message.'); return; }
  var text = encodeURIComponent('Hi Prakash, my name is ' + name + '. ' + msg);
  window.open('https://api.whatsapp.com/send?phone=+918447385389&text=' + text, '_blank');
}
</script>

<?php get_footer(); ?>
