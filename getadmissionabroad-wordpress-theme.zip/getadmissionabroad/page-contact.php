<?php
/**
 * Template Name: Contact
 * Template for: /contact
 */
get_header();
$instagram_url = 'https://www.instagram.com/prakashabroad/';
?>

<section class="page-hero">
  <div class="container">
    <h1>Get in <span class="gold">Touch</span></h1>
    <p>Reach out to Prakash directly, by email or Instagram. He responds to every serious inquiry personally.</p>
  </div>
</section>

<section class="section bg-white">
  <div class="container">
    <div class="two-col">
      <!-- Contact Details -->
      <div>
        <h2 style="margin-bottom:1.5rem;">Contact Details</h2>
        <div style="display:flex;flex-direction:column;gap:1rem;">

          <a href="mailto:getadmissionabroad.in@gmail.com" class="contact-card email">
            <span class="contact-icon-big">✉️</span>
            <div>
              <p class="contact-name">Email</p>
              <p class="contact-val">getadmissionabroad.in@gmail.com</p>
            </div>
          </a>

          <a href="<?php echo esc_url($instagram_url); ?>" target="_blank" rel="noopener noreferrer" class="contact-card instagram">
            <span class="contact-icon-big">📷</span>
            <div>
              <p class="contact-name">Instagram</p>
              <p class="contact-val">@prakashabroad</p>
            </div>
          </a>

          <div class="contact-card address">
            <span class="contact-icon-big">📍</span>
            <div>
              <p class="contact-name">Location</p>
              <p class="contact-val">Delhi, India</p>
            </div>
          </div>

        </div>
      </div>

      <!-- Send a Message form (email via AJAX) -->
      <div>
        <h2 style="margin-bottom:0.75rem;">Send a Message</h2>
        <p style="font-size:0.875rem;color:#6b7280;margin-bottom:1.5rem;">Fill in your details and Prakash will get back to you by email or phone within 24 hours.</p>

        <div id="contact-form-wrap">
          <div class="form-group">
            <label class="form-label" for="cf-name">Your Name *</label>
            <input class="form-input" type="text" id="cf-name" placeholder="e.g. Riya Sharma" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="cf-email">Email Address *</label>
            <input class="form-input" type="email" id="cf-email" placeholder="e.g. riya@email.com" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="cf-phone">Phone Number</label>
            <input class="form-input" type="tel" id="cf-phone" placeholder="e.g. 9876543210" maxlength="10">
          </div>
          <div class="form-group">
            <label class="form-label" for="cf-msg">Your Message *</label>
            <textarea class="form-textarea" id="cf-msg" rows="5" placeholder="e.g. I'm a final year engineering student looking to apply for MS in CS in the US. Can we discuss my profile?" required></textarea>
          </div>
          <div id="cf-error" class="form-error" style="display:none;"></div>
          <button type="button" onclick="gaaSendMessage()" class="btn btn-gold" style="width:100%;justify-content:center;padding:0.875rem;margin-top:0.5rem;">
            Send Message →
          </button>
        </div>

        <div id="cf-success" class="form-success" style="display:none;">
          <span class="check-big">✅</span>
          <h3>Message Sent!</h3>
          <p>Prakash will reply to your email within 24 hours.</p>
          <a href="<?php echo esc_url(home_url('/book')); ?>" class="btn btn-navy" style="margin-top:1.25rem;">Book a Free Call</a>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
function gaaSendMessage() {
  var name  = document.getElementById('cf-name').value.trim();
  var email = document.getElementById('cf-email').value.trim();
  var phone = document.getElementById('cf-phone').value.trim();
  var msg   = document.getElementById('cf-msg').value.trim();
  var errEl = document.getElementById('cf-error');
  errEl.style.display = 'none';

  if (!name)  { errEl.textContent = 'Please enter your name.'; errEl.style.display = 'block'; return; }
  if (!email || !/^[^@]+@[^@]+\.[^@]+$/.test(email)) { errEl.textContent = 'Please enter a valid email.'; errEl.style.display = 'block'; return; }
  if (!msg)   { errEl.textContent = 'Please enter a message.'; errEl.style.display = 'block'; return; }

  var btn = document.querySelector('#contact-form-wrap button');
  btn.textContent = 'Sending…';
  btn.disabled = true;

  var fd = new FormData();
  fd.append('action', 'gaa_contact_email');
  fd.append('nonce',  gaaData.nonce);
  fd.append('name',   name);
  fd.append('email',  email);
  fd.append('phone',  phone);
  fd.append('message', msg);

  fetch(gaaData.ajaxUrl, { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(data) {
      if (data.success) {
        document.getElementById('contact-form-wrap').style.display = 'none';
        document.getElementById('cf-success').style.display = 'block';
      } else {
        errEl.textContent = (data.data && data.data.error) || 'Something went wrong. Please try again.';
        errEl.style.display = 'block';
        btn.textContent = 'Send Message →';
        btn.disabled = false;
      }
    })
    .catch(function() {
      errEl.textContent = 'Network error. Please try again.';
      errEl.style.display = 'block';
      btn.textContent = 'Send Message →';
      btn.disabled = false;
    });
}
</script>

<?php get_footer(); ?>
