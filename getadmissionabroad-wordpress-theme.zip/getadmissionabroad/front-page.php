<?php
/**
 * Home page template (front-page.php)
 */
get_header();
$book_url    = esc_url(home_url('/book'));
$contact_url = esc_url(home_url('/contact'));
$ig_url      = 'https://www.instagram.com/prakashabroad/';
?>

<!-- ── HERO ────────────────────────────────────────────── -->
<section class="hero">
  <div class="hero-rings">
    <div class="hero-ring-1"></div>
    <div class="hero-ring-2"></div>
    <div class="hero-glow"></div>
  </div>
  <div class="container">
    <div class="hero-grid">
      <div>
        <div class="hero-badge">
          <span>⭐</span>
          <span>5-Star Rated · Delhi's Founder-Led Consultancy</span>
        </div>
        <h1>
          Get Admitted to Top Universities Abroad<br>
          <span class="gold">Led Personally by Prakash</span>
        </h1>
        <p class="hero-desc">Every step handled with strategy, honesty, and complete transparency. You work directly with Prakash, never a junior counsellor.</p>
        <div class="hero-buttons">
          <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">
            Book a Free Call
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
          </a>
          <a href="<?php echo $contact_url; ?>" class="btn btn-outline-white btn-lg">Get in Touch →</a>
        </div>
        <div class="hero-chips">
          <?php foreach (['Delhi-based', 'Founder-led', 'STEM to Humanities', 'Targeting all Universities'] as $chip): ?>
            <span class="hero-chip">✓ <?php echo esc_html($chip); ?></span>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="hero-contact-form">
        <div class="hero-form-inner">
          <p class="hero-form-title">Get a Free Profile Review</p>
          <p class="hero-form-sub">Prakash will reply within 24 hours.</p>
          <div id="hero-form-wrap" style="display:flex;flex-direction:column;gap:0.75rem;margin-top:1.25rem;">
            <input class="form-input form-input-light" type="text" id="hf-name" placeholder="Your Name" required>
            <input class="form-input form-input-light" type="email" id="hf-email" placeholder="Email Address" required>
            <input class="form-input form-input-light" type="tel" id="hf-phone" placeholder="Phone Number" maxlength="10">
            <textarea class="form-textarea form-input-light" id="hf-msg" rows="3" placeholder="Briefly describe your profile and goals…" required></textarea>
            <div id="hf-error" style="display:none;color:#fca5a5;font-size:0.8rem;"></div>
            <button type="button" onclick="gaaHeroSubmit()" class="btn btn-gold" style="width:100%;justify-content:center;padding:0.8rem;">
              Send to Prakash →
            </button>
          </div>
          <div id="hf-success" style="display:none;text-align:center;padding:2rem 0;">
            <div style="font-size:2.5rem;">✅</div>
            <p style="color:#fff;font-weight:700;margin-top:0.75rem;">Message Sent!</p>
            <p style="color:#d1d5db;font-size:0.875rem;margin-top:0.5rem;">Prakash will be in touch within 24 hours.</p>
          </div>
          <p style="margin-top:1rem;font-size:0.72rem;color:rgba(255,255,255,0.5);text-align:center;">Or <a href="<?php echo $book_url; ?>" style="color:var(--gold);text-decoration:underline;">book a call directly →</a></p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── PROOF BAR ────────────────────────────────────────── -->
<section class="proof-bar">
  <div class="container">
    <div class="proof-grid">
      <?php
      $proof = [
        ['🌍', '40+ Countries',      'US · UK · Canada · Australia · UAE & more'],
        ['🎓', 'All Universities',   'Ivy to regional — every profile'],
        ['📝', 'All Documents',     'SOP · LOR · Essays · CV'],
        ['⭐', '5.0 Google Rating', 'Verified student reviews'],
      ];
      foreach ($proof as $p):
      ?>
      <div class="proof-item">
        <div class="icon"><?php echo $p[0]; ?></div>
        <p><?php echo esc_html($p[1]); ?></p>
        <span><?php echo esc_html($p[2]); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── UNIVERSITY BELT ──────────────────────────────────── -->
<section class="uni-belt">
  <div class="container">
    <p class="label">Universities Our Students Target</p>
    <div class="uni-tags">
      <?php
      $unis = ['Harvard','MIT','Stanford','Columbia','Oxford','Cambridge','LSE','Imperial College','University of Toronto','UBC','McGill','NYU','UNSW Sydney','Melbourne','NYU Abu Dhabi'];
      foreach ($unis as $uni):
      ?>
      <span class="uni-tag"><?php echo esc_html($uni); ?></span>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── MEET PRAKASH ─────────────────────────────────────── -->
<section class="section bg-white">
  <div class="container">
    <div class="two-col">
      <div class="photo-card-wrap" style="justify-content:flex-start;">
        <div class="photo-card">
          <div class="photo-frame" style="height:440px;">
            <img src="https://sop-writer.in/wp-content/uploads/2026/02/prakash-sop-india.jpg" alt="Prakash — Founder, Get Admission Abroad" loading="lazy">
            <div class="photo-overlay"></div>
            <div class="photo-label">
              <p>Prakash</p>
              <p>Founder · Get Admission Abroad</p>
            </div>
          </div>
          <div style="position:absolute;top:-1rem;right:-1rem;background:var(--gold);border-radius:1rem;padding:0.75rem 1rem;color:#fff;text-align:center;box-shadow:0 4px 12px rgba(201,168,76,0.4);">
            <p style="font-size:1.5rem;font-weight:800;line-height:1;">8+</p>
            <p style="font-size:0.7rem;font-weight:600;">Years' Experience</p>
          </div>
          <div style="position:absolute;bottom:-1rem;left:-1rem;background:#fff;border-radius:1rem;padding:0.75rem 1rem;border:1px solid #f3f4f6;box-shadow:0 4px 16px rgba(0,0,0,0.1);text-align:center;">
            <p style="font-size:1.5rem;font-weight:800;color:var(--navy);line-height:1;">10,000+</p>
            <p style="font-size:0.7rem;color:#6b7280;">Students Guided</p>
          </div>
        </div>
      </div>
      <div>
        <div class="section-title">
          <p class="eyebrow">Your Consultant</p>
          <h2>Meet Prakash</h2>
          <div class="gold-bar"></div>
        </div>
        <p style="color:#4b5563;line-height:1.7;">Hi, I'm Prakash — the founder of Get Admission Abroad. I built this practice on a single belief: every student deserves honest, personalised guidance from someone who's genuinely invested in their outcome.</p>
        <p style="color:#4b5563;line-height:1.7;margin-top:1rem;">Unlike large consultancies where you meet a senior and then get passed to a junior, here you work directly with me — at every step. From your first profile call to your final submission, you'll always know exactly what we're doing and why.</p>
        <ul class="checklist" style="margin-top:1.75rem;">
          <?php
          $points = [
            '8+ years guiding students across India',
            '10,000+ students helped to universities in US, UK, Canada, Australia & UAE',
            'STEM, Humanities, MBA, Public Policy, Law, Public Health & more',
            'Direct access to Prakash at all times',
            'No templates. Every SOP and strategy built from scratch',
          ];
          foreach ($points as $point):
          ?>
          <li>
            <span class="check">
              <svg fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
            </span>
            <?php echo esc_html($point); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <div style="margin-top:2.25rem;display:flex;flex-wrap:wrap;gap:0.75rem;">
          <a href="<?php echo $book_url; ?>" class="btn btn-gold">Book a Free Call with Prakash</a>
          <a href="<?php echo esc_url(home_url('/about-prakash')); ?>" class="btn btn-outline-navy">Full Bio →</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ── STUDENTS vs PARENTS ───────────────────────────────── -->
<section class="section bg-white" style="padding-top:0;">
  <div class="container">
    <div class="section-title center">
      <h2>Who Do We Work With?</h2>
      <p class="subtitle">Whether you're the student or the parent writing the cheque, we've got you covered.</p>
    </div>
    <div class="grid-3">
      <div class="card card-navy" style="padding:2rem;border-radius:1.5rem;overflow:hidden;position:relative;">
        <div style="font-size:2.5rem;margin-bottom:1rem;">🎓</div>
        <h3 style="font-size:1.5rem;color:#fff;margin-bottom:0.5rem;">For Students</h3>
        <p style="color:#9ca3af;font-size:0.875rem;margin-bottom:1.5rem;">Your complete admissions partner, from profile to admit.</p>
        <ul class="checklist checklist-white">
          <?php foreach (['Profile building from early stage','Strategic university shortlisting','Complete application execution','SOP, LOR, and all documentation','Honest fit assessment, no over-promising'] as $item): ?>
          <li style="color:#e5e7eb;">
            <span class="check" style="background:rgba(201,168,76,0.2);">
              <svg fill="none" stroke="#c9a84c" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
            </span>
            <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo esc_url(home_url('/services')); ?>" class="btn btn-gold" style="margin-top:2rem;">Explore Services →</a>
      </div>
      <div class="card card-amber" style="padding:2rem;border-radius:1.5rem;border:2px solid rgba(201,168,76,0.3);">
        <div style="font-size:2.5rem;margin-bottom:1rem;">👨‍👩‍👧</div>
        <h3 style="font-size:1.5rem;color:var(--navy);margin-bottom:0.5rem;">For Parents</h3>
        <p style="color:#6b7280;font-size:0.875rem;margin-bottom:1.5rem;">Full transparency so you're never left in the dark.</p>
        <ul class="checklist">
          <?php foreach (['Full transparency on process and costs','Clear timeline with milestones','Weekly progress updates','Ethical guidance, no fake promises','Direct access to Prakash at all times'] as $item): ?>
          <li>
            <span class="check" style="background:rgba(26,39,68,0.08);">
              <svg fill="none" stroke="var(--navy)" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
            </span>
            <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo esc_url(home_url('/parents')); ?>" class="btn btn-navy" style="margin-top:2rem;">Parents' Guide →</a>
      </div>
      <div class="card" style="padding:2rem;border-radius:1.5rem;border:2px solid rgba(201,168,76,0.3);background:#fff;">
        <div style="font-size:2.5rem;margin-bottom:1rem;">⚡</div>
        <h3 style="font-size:1.5rem;color:var(--navy);margin-bottom:0.5rem;">Fastrack Processing</h3>
        <p style="color:#6b7280;font-size:0.875rem;margin-bottom:1.5rem;">Direct application without the full profile-building phase.</p>
        <ul class="checklist">
          <?php foreach (['For students with a clear university target','Rapid shortlisting and documentation','SOP and LOR in a compressed timeline','Best for 8–12 weeks to deadline','No shortcuts on quality'] as $item): ?>
          <li>
            <span class="check" style="background:rgba(26,39,68,0.08);">
              <svg fill="none" stroke="var(--navy)" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
            </span>
            <?php echo esc_html($item); ?>
          </li>
          <?php endforeach; ?>
        </ul>
        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-navy" style="margin-top:2rem;">Get in Touch →</a>
      </div>
    </div>
  </div>
</section>

<!-- ── HOW IT WORKS ──────────────────────────────────────── -->
<section class="section bg-gray">
  <div class="container">
    <div class="section-title center">
      <h2>How It Works</h2>
      <p class="subtitle">Four clear steps from enquiry to admit.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="process-steps" style="margin-top:3.5rem;">
      <?php
      $steps = [
        ['📞', 'Free Discovery Call',    'Honest initial feedback on your profile and realistic options. 15 minutes with Prakash.'],
        ['🔍', 'Profile Deep Dive',      'Detailed assessment of academics, activities, and goals. Target range set.'],
        ['✍️', 'Strategy & Execution',   'Shortlist finalised, essays crafted, applications built, every step guided.'],
        ['🎉', 'Submit & Decide',        'All materials submitted before deadlines. Post-admit guidance to pick the right offer.'],
      ];
      foreach ($steps as $i => $s):
      ?>
      <div class="process-step">
        <div class="step-icon-wrap">
          <div class="step-icon"><?php echo $s[0]; ?></div>
          <span class="step-num"><?php echo $i+1; ?></span>
        </div>
        <h3><?php echo esc_html($s[1]); ?></h3>
        <p><?php echo esc_html($s[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:2.5rem;">
      <a href="<?php echo $book_url; ?>" class="btn btn-navy">Start with a Free Call →</a>
    </div>
  </div>
</section>

<!-- ── SERVICES OVERVIEW ─────────────────────────────────── -->
<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <h2>What We Offer</h2>
      <p class="subtitle">Every service personally handled by Prakash.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-3" style="margin-top:3rem;">
      <?php
      $services = [
        ['🏗️','bg-blue-50 text-blue-700','Early Stage — 12–18 months out','Profile Building Mentorship','Identify your strengths, close gaps, build a compelling narrative before a single application is written.','/services#profile'],
        ['🎯','bg-amber-50 text-amber-700','Core Service — 4–6 months out','University Admissions Strategy','Research-backed shortlisting, school-specific positioning, and full application management.','/services#strategy'],
        ['📝','bg-green-50 text-green-700','Also Standalone — any stage','Documentation & Storytelling','SOPs, personal statements, LORs, and every supporting document crafted precisely for each school.','/services#documentation'],
      ];
      foreach ($services as $svc):
      ?>
      <a href="<?php echo esc_url(home_url($svc[5])); ?>" class="service-card">
        <div class="icon"><?php echo $svc[0]; ?></div>
        <span class="stage-badge" style="background:#fef3c7;color:#92400e;"><?php echo esc_html($svc[2]); ?></span>
        <h3><?php echo esc_html($svc[3]); ?></h3>
        <p><?php echo esc_html($svc[4]); ?></p>
        <span class="cta-link">Learn more <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg></span>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── WHERE ARE YOU IN YOUR JOURNEY ────────────────────── -->
<section class="section bg-navy">
  <div class="container">
    <div class="section-title center light">
      <h2>Where Are You in Your Journey?</h2>
      <p class="subtitle">Wherever you are, there's a tailored plan.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-3" style="margin-top:3rem;">
      <?php
      $tiles = [
        ['📅','badge-green','Best time to start','6–18 Months Out','We build your profile, identify gaps, choose targets, and prepare a full strategy so nothing is rushed.','Start with a profile evaluation call.','/book'],
        ['⏱️','badge-amber','Application season','3–6 Months Out','We finalise your shortlist, build your narrative, and begin documentation immediately.','Book a call to map your deadlines.','/book'],
        ['🚨','badge-red','Urgent — contact now','0–8 Weeks to Deadline','Tight timelines need disciplined execution. We prioritise the right schools and get materials submission-ready.','Email us now — time matters.',$contact_url],
      ];
      foreach ($tiles as $t):
      ?>
      <div class="journey-tile">
        <div class="header">
          <div class="icon"><?php echo $t[0]; ?></div>
          <span class="badge <?php echo $t[1]; ?>"><?php echo esc_html($t[2]); ?></span>
        </div>
        <h3><?php echo esc_html($t[3]); ?></h3>
        <p><?php echo esc_html($t[4]); ?></p>
        <div class="next-step">
          <p class="eyebrow">Next Step</p>
          <a href="<?php echo esc_url($t[6]); ?>" <?php echo strpos($t[6],'http')===0 ? 'target="_blank" rel="noopener noreferrer"' : ''; ?>>
            <?php echo esc_html($t[5]); ?> →
          </a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── COUNTRIES ─────────────────────────────────────────── -->
<section class="section bg-gray">
  <div class="container">
    <div class="section-title center">
      <h2>Countries We Specialise In</h2>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-5" style="margin-top:3rem;">
      <?php
      $countries = [
        ['🇺🇸','United States','Ivy, State & Liberal Arts','/countries#us'],
        ['🇬🇧','United Kingdom','Russell Group · Oxbridge','/countries#uk'],
        ['🇨🇦','Canada','UBC, Toronto, McGill','/countries#canada'],
        ['🇦🇺','Australia','Group of Eight unis','/countries#australia'],
        ['🇦🇪','UAE','NYU Abu Dhabi & more','/countries#uae'],
      ];
      foreach ($countries as $c):
      ?>
      <a href="<?php echo esc_url(home_url($c[3])); ?>" class="country-card">
        <div class="flag"><?php echo $c[0]; ?></div>
        <p class="name"><?php echo esc_html($c[1]); ?></p>
        <p class="note"><?php echo esc_html($c[2]); ?></p>
      </a>
      <?php endforeach; ?>
    </div>
    <p style="text-align:center;margin-top:1.5rem;">
      <a href="<?php echo esc_url(home_url('/countries')); ?>" style="font-size:0.875rem;font-weight:700;color:var(--navy);text-decoration:underline;text-underline-offset:4px;">Explore all destinations →</a>
    </p>
    <p style="text-align:center;margin-top:0.75rem;font-size:0.8rem;color:#6b7280;">Also accepting applications for: Ireland, Italy, Singapore, New Zealand, Germany, Netherlands and more.</p>
  </div>
</section>

<!-- ── TESTIMONIALS ──────────────────────────────────────── -->
<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <h2>What Students Say</h2>
      <p class="subtitle">Verified Google Reviews from real students.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="grid-2" style="margin-top:3rem;">
      <?php
      $testimonials = [
        ['Ankita Dwivedi',     'I had a really smooth experience with this consultancy while applying for my studies abroad. They guided me through every step from university shortlisting to application and documentation. What I appreciated the most was their responsiveness and clarity in communication. Highly recommend to anyone planning to study abroad!'],
        ['Bushra Sayeed Imam', 'The best service you can get for admissions guidance — within one\'s budget and time frame. Not just documentation help but also guidance and suggestions throughout. Finally got into my dream college.'],
        ['Pranjal Sethi',      'Thank you so much for the help. It really means a lot to me — I got my offer letter and I can\'t thank enough. God bless you.'],
        ['Mahima Choudhary',   'I just wanted to express my heartfelt gratitude for all the help in crafting a compelling statement of purpose that helped me get into my dream university. The assistance made a real difference, and I could not have done it without you.'],
      ];
      foreach ($testimonials as $t):
      ?>
      <div class="testimonial-card">
        <div class="testimonial-stars">★★★★★</div>
        <p class="testimonial-text">"<?php echo esc_html($t[1]); ?>"</p>
        <p class="testimonial-name">— <?php echo esc_html($t[0]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:2rem;">
      <a href="<?php echo esc_url(home_url('/success-stories')); ?>" style="font-size:0.875rem;font-weight:700;color:var(--navy);text-decoration:underline;text-underline-offset:4px;">Read more success stories →</a>
    </div>
  </div>
</section>

<!-- ── COMPARISON TABLE ──────────────────────────────────── -->
<section class="section bg-gray">
  <div class="container">
    <div class="section-title center">
      <h2>Why Prakash Over a Typical Consultancy?</h2>
      <p class="subtitle">Honest comparison, you decide.</p>
      <div class="gold-bar"></div>
    </div>
    <div class="comparison-table" style="margin-top:3rem;">
      <div class="comparison-header">
        <div class="comparison-header-row">
          <span style="color:#9ca3af;">Feature</span>
          <span class="us">Get Admission Abroad</span>
          <span class="them">Typical Consultancy</span>
        </div>
      </div>
      <?php
      $rows = [
        ['Who guides you?',          'Founder (Prakash), always',        'Junior counsellor after initial call'],
        ['Templates used?',          'Never, built from scratch',         'Often — same SOPs for many'],
        ['University shortlisting',  'Research-backed + honest',           'Schools that look impressive'],
        ['Communication',            'Direct, phone/email/call',              'Ticketing system / scheduler'],
        ['Success fee pressure?',    'None — we\'re honest',              'Can lead to over-promising'],
        ['Progress updates',         'Weekly, proactive',                  'When you ask'],
      ];
      foreach ($rows as $row):
      ?>
      <div class="comparison-row">
        <span class="feature"><?php echo esc_html($row[0]); ?></span>
        <span class="us-val">
          <svg width="16" height="16" fill="none" stroke="#16a34a" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"/></svg>
          <?php echo esc_html($row[1]); ?>
        </span>
        <span class="them-val"><?php echo esc_html($row[2]); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── FAQ ───────────────────────────────────────────────── -->
<section class="section bg-white">
  <div class="container">
    <div class="section-title center">
      <h2>Frequently Asked Questions</h2>
      <div class="gold-bar"></div>
    </div>
    <div class="faq-list" style="margin-top:3rem;">
      <?php
      $faqs = [
        ['Do you only work with students from Delhi?',
         'No — Prakash works with students from across India and abroad. Sessions are online (Google Meet/Zoom/phone call), so location is no barrier.'],
        ['Is the first call really free?',
         'Yes, completely. The first 15-minute call is free, no card required, no commitment. It\'s simply an honest conversation about your profile and whether we\'re a good fit.'],
        ['How early should I start?',
         'The earlier, the better — ideally 12–18 months before your application deadlines. That\'s when Prakash can genuinely improve your profile, not just document it.'],
        ['What if my grades aren\'t that strong?',
         'Grades are one factor, not the only one. Many students with moderate academic scores have received strong admits with the right narrative strategy and school selection.'],
        ['Do you guarantee admission?',
         'No. Anyone who guarantees admission is misleading you. What Prakash guarantees is an honest, well-researched, professionally executed application, one that gives you the best realistic chance.'],
        ['What countries and programs do you cover?',
         'Primary destinations: US, UK, Canada, Australia, and UAE. We also work with students applying to Ireland, Italy, Singapore, New Zealand, Germany, and Netherlands. Programs covered include undergraduate, postgraduate (MS, MA, MiM), MBA, law, medicine, public policy, public health, and more.'],
        ['What does it cost?',
         'Fees depend on the scope of service and are discussed transparently before any engagement. There are no hidden charges.'],
      ];
      foreach ($faqs as $faq):
      ?>
      <div class="faq-item">
        <button class="faq-q" aria-expanded="false">
          <?php echo esc_html($faq[0]); ?>
          <svg class="chevron" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <div class="faq-a"><?php echo esc_html($faq[1]); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── FINAL CTA ─────────────────────────────────────────── -->
<section class="cta-section" style="position:relative;overflow:hidden;">
  <div style="position:absolute;inset:0;pointer-events:none;">
    <div style="position:absolute;top:0;left:50%;transform:translateX(-50%);width:600px;height:300px;background:rgba(201,168,76,0.05);border-radius:50%;filter:blur(60px);"></div>
  </div>
  <div class="container" style="position:relative;">
    <div style="max-width:640px;margin:0 auto;">
      <div class="cta-badge"><span>Free · No Obligation · 15 Minutes</span></div>
      <h2>Book Your Free Call Today</h2>
      <p>Tell Prakash about your profile. He'll give you his honest initial read, no hard sell, no commitment.</p>
      <div class="cta-buttons">
        <a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a>
        <a href="<?php echo $contact_url; ?>" class="btn btn-outline-white btn-lg">Get in Touch →</a>
      </div>
    </div>
  </div>
</section>

<script>
function gaaHeroSubmit() {
  var name  = document.getElementById('hf-name').value.trim();
  var email = document.getElementById('hf-email').value.trim();
  var phone = document.getElementById('hf-phone').value.trim();
  var msg   = document.getElementById('hf-msg').value.trim();
  var errEl = document.getElementById('hf-error');
  errEl.style.display = 'none';

  if (!name)  { errEl.textContent = 'Please enter your name.'; errEl.style.display = 'block'; return; }
  if (!email || !/^[^@]+@[^@]+\.[^@]+$/.test(email)) { errEl.textContent = 'Please enter a valid email.'; errEl.style.display = 'block'; return; }
  if (!msg)   { errEl.textContent = 'Please enter a message.'; errEl.style.display = 'block'; return; }

  var btn = document.querySelector('#hero-form-wrap button');
  btn.textContent = 'Sending…';
  btn.disabled = true;

  var fd = new FormData();
  fd.append('action',  'gaa_contact_email');
  fd.append('nonce',   gaaData.nonce);
  fd.append('name',    name);
  fd.append('email',   email);
  fd.append('phone',   phone);
  fd.append('message', msg);

  fetch(gaaData.ajaxUrl, { method: 'POST', body: fd })
    .then(function(r){ return r.json(); })
    .then(function(data) {
      if (data.success) {
        document.getElementById('hero-form-wrap').style.display = 'none';
        document.getElementById('hf-success').style.display = 'block';
      } else {
        errEl.textContent = (data.data && data.data.error) || 'Something went wrong. Please try again.';
        errEl.style.display = 'block';
        btn.textContent = 'Send to Prakash →';
        btn.disabled = false;
      }
    })
    .catch(function() {
      errEl.textContent = 'Network error. Please try again.';
      errEl.style.display = 'block';
      btn.textContent = 'Send to Prakash →';
      btn.disabled = false;
    });
}
</script>

<?php get_footer(); ?>
