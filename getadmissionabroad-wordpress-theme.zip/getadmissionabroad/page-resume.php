<?php
/**
 * Template Name: Resume Support
 * Template for: /resume
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>
<section class="page-hero"><div class="container"><h1>Resume Support</h1><p>Build professional resumes that clearly showcase profile strength and impact.</p></div></section>
<section class="section bg-white"><div class="container"><div class="two-col"><div><h2>Resume support includes</h2><ul style="margin-top:1rem;display:flex;flex-direction:column;gap:0.65rem;"><?php foreach (['Profile-to-resume mapping','Impact-driven bullet and section rewrite','Academic/professional formatting support','Program-aligned resume reviews'] as $item): ?><li style="display:flex;gap:0.5rem;"><span class="check-gold">✓</span><?php echo esc_html($item); ?></li><?php endforeach; ?></ul></div><div class="card card-amber" style="align-self:start;"><h3>Outcome</h3><p style="color:#4b5563;">A clean, credible, and admissions-ready professional profile.</p></div></div></div></section>
<section class="cta-section"><div class="container" style="text-align:center;"><h2>Upgrade your resume</h2><div class="cta-buttons"><a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a><a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Contact Us</a></div></div></section>
<?php get_footer(); ?>
