/**
 * Get Admission Abroad — main.js
 * Handles: sticky header shadow, mobile menu, FAQ accordion
 */
(function () {
  'use strict';

  // ── Sticky header shadow ─────────────────────────────────
  var header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 10) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  // ── Mobile menu toggle ───────────────────────────────────
  var hamburger  = document.getElementById('hamburger');
  var mobileMenu = document.getElementById('mobile-menu');
  var hamIcon    = document.getElementById('ham-icon');
  var closeIcon  = document.getElementById('close-icon');

  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', function () {
      var isOpen = mobileMenu.classList.toggle('open');
      hamburger.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      if (hamIcon)   hamIcon.style.display   = isOpen ? 'none'  : '';
      if (closeIcon) closeIcon.style.display = isOpen ? ''      : 'none';
    });

    // Close menu when a link inside it is clicked
    mobileMenu.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        mobileMenu.classList.remove('open');
        hamburger.setAttribute('aria-expanded', 'false');
        if (hamIcon)   hamIcon.style.display   = '';
        if (closeIcon) closeIcon.style.display = 'none';
      });
    });
  }

  // ── FAQ accordion ────────────────────────────────────────
  document.querySelectorAll('.faq-item').forEach(function (item) {
    var btn = item.querySelector('.faq-q');
    if (!btn) return;
    btn.addEventListener('click', function () {
      var isOpen = item.classList.toggle('open');
      btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
  });

})();
