<?php
/**
 * Template Name: Research Proposal Guidance
 * Template for: /research-proposal
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>
<section class="page-hero"><div class="container"><h1>Research Proposal Guidance</h1><p>We help students craft better research proposals through structure and feedback. We do not write proposals.</p></div></section>
<section class="section bg-white"><div class="container"><div class="two-col"><div><h2>Guidance areas</h2><ul style="margin-top:1rem;display:flex;flex-direction:column;gap:0.65rem;"><?php foreach (['Topic refinement and scope clarity','Research objective and methodology structuring','Alignment with faculty/program focus','Review feedback on draft proposals'] as $item): ?><li style="display:flex;gap:0.5rem;"><span class="check-gold">✓</span><?php echo esc_html($item); ?></li><?php endforeach; ?></ul></div><div class="card card-amber" style="align-self:start;"><h3>Policy</h3><p style="color:#4b5563;">We mentor and review. Students author the proposal themselves.</p></div></div></div></section>
<section class="cta-section"><div class="container" style="text-align:center;"><h2>Need research proposal guidance?</h2><div class="cta-buttons"><a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a><a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Contact Us</a></div></div></section>
<?php get_footer(); ?>
