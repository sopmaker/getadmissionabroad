<?php
/**
 * Template Name: Book a Session
 * Template for: /book
 */
get_header();
?>

<section class="page-hero">
  <div class="container">
    <h1>Book a Call with <span class="gold">Prakash</span></h1>
    <p>15 minutes. No obligations. You'll leave knowing your realistic options, timeline, and next step.</p>
  </div>
</section>

<section class="section bg-gray">
  <div class="container">
    <div style="max-width:760px;margin:0 auto;background:#fff;border-radius:1.5rem;border:1px solid #f3f4f6;box-shadow:0 2px 12px rgba(0,0,0,0.05);padding:2.5rem;">

      <!-- Step 1: Select Date -->
      <div id="step-date">
        <h2 class="booking-section-title">1. Select a Date</h2>
        <div id="date-picker"></div>
      </div>

      <!-- Step 2: Select Slot (shown after date selected) -->
      <div id="step-slot" class="booking-step">
        <h2 class="booking-section-title" id="slot-heading">2. Select a Time Slot</h2>
        <div class="slot-grid" id="slot-grid"></div>
      </div>

      <!-- Step 3: Personal Details (shown after slot selected) -->
      <div id="step-details" class="booking-step">
        <h2 class="booking-section-title">3. Your Details</h2>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label" for="b-name">Full Name *</label>
            <input class="form-input" type="text" id="b-name" placeholder="e.g. Riya Sharma" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="b-email">Email Address *</label>
            <input class="form-input" type="email" id="b-email" placeholder="e.g. riya@email.com" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="b-phone">Phone Number (10 digits) *</label>
            <input class="form-input" type="tel" id="b-phone" placeholder="e.g. 9876543210" maxlength="10" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="b-msg">Your Requirement *</label>
            <textarea class="form-textarea" id="b-msg" rows="3" placeholder="e.g. I'm a final year B.Tech student looking to apply for MS in CS in the US next year."></textarea>
          </div>
        </div>
        <div id="booking-error" class="form-error" style="display:none;"></div>
        <div id="booking-summary" class="form-summary" style="display:none;"></div>
        <button type="button" id="confirm-btn" onclick="gaaConfirmBooking()" class="btn btn-gold btn-lg" style="width:100%;justify-content:center;margin-top:1rem;">
          Confirm Booking
        </button>
      </div>

      <!-- Confirmation screen -->
      <div id="step-confirmed" class="booking-step">
        <div class="form-success" style="padding:3rem 2rem;">
          <span class="check-big">✅</span>
          <h3>Booking Confirmed!</h3>
          <p id="confirm-msg" style="margin-top:0.5rem;"></p>
          <p style="margin-top:1rem;font-size:0.8rem;color:#6b7280;">Thanks for booking. Prakash will review your details and reach out on WhatsApp/phone before the call.</p>
          <a href="mailto:getadmissionabroad.in@gmail.com" class="btn btn-navy" style="margin-top:1.5rem;">✉️ Email Prakash</a>
        </div>
      </div>

    </div>
  </div>
</section>

<script>
(function() {
  var DAY_NAMES   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  var MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];

  // Generate time slots 10:00 AM – 8:30 PM
  var TIME_SLOTS = [];
  for (var h = 10; h <= 20; h++) {
    ['00','30'].forEach(function(m) {
      var h12  = h > 12 ? h - 12 : h;
      var ampm = h >= 12 ? 'PM' : 'AM';
      TIME_SLOTS.push((h12 < 10 ? '0' : '') + h12 + ':' + m + ' ' + ampm);
    });
  }

  // Generate next 30 days (skip Sundays)
  var DATES = [];
  var today = new Date(); today.setHours(0,0,0,0);
  for (var i = 1; i <= 30; i++) {
    var d = new Date(today); d.setDate(today.getDate() + i);
    if (d.getDay() !== 0) DATES.push(d);
  }

  function fmtVal(d) {
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  }
  function fmtDisplay(d) {
    return DAY_NAMES[d.getDay()] + ', ' + d.getDate() + ' ' + MONTH_NAMES[d.getMonth()] + ' ' + d.getFullYear();
  }

  var selectedDate = null;
  var selectedSlot = '';

  // Build date picker
  var picker = document.getElementById('date-picker');
  var groups = {};
  DATES.forEach(function(d) {
    var key = MONTH_NAMES[d.getMonth()] + ' ' + d.getFullYear();
    if (!groups[key]) groups[key] = [];
    groups[key].push(d);
  });
  Object.keys(groups).forEach(function(month) {
    var label = document.createElement('p');
    label.className = 'date-month-label';
    label.textContent = month;
    picker.appendChild(label);

    var grid = document.createElement('div');
    grid.className = 'date-grid';
    groups[month].forEach(function(d) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'date-btn';
      btn.dataset.val = fmtVal(d);
      btn.innerHTML = '<span>' + DAY_NAMES[d.getDay()] + '</span><span class="day-num">' + d.getDate() + '</span>';
      btn.addEventListener('click', function() {
        document.querySelectorAll('.date-btn').forEach(function(b){ b.classList.remove('selected'); });
        btn.classList.add('selected');
        selectedDate = d;
        selectedSlot = '';
        buildSlots(d);
        document.getElementById('step-slot').classList.add('active');
        document.getElementById('step-details').classList.remove('active');
        document.getElementById('slot-heading').textContent = '2. Select a Time Slot — ' + fmtDisplay(d);
        document.querySelectorAll('.slot-btn').forEach(function(s){ s.classList.remove('selected'); });
        document.getElementById('booking-summary').style.display = 'none';
      });
      grid.appendChild(btn);
    });
    picker.appendChild(grid);
  });

  function buildSlots(d) {
    var grid = document.getElementById('slot-grid');
    grid.innerHTML = '';
    TIME_SLOTS.forEach(function(slot) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'slot-btn';
      btn.textContent = slot;
      btn.addEventListener('click', function() {
        document.querySelectorAll('.slot-btn').forEach(function(b){ b.classList.remove('selected'); });
        btn.classList.add('selected');
        selectedSlot = slot;
        document.getElementById('step-details').classList.add('active');
        var summary = document.getElementById('booking-summary');
        summary.style.display = 'block';
        summary.innerHTML = '<strong>Booking Summary:</strong> ' + fmtDisplay(selectedDate) + ' at ' + selectedSlot + ' IST';
      });
      grid.appendChild(btn);
    });
  }

  window.gaaConfirmBooking = function() {
    var name  = document.getElementById('b-name').value.trim();
    var email = document.getElementById('b-email').value.trim();
    var phone = document.getElementById('b-phone').value.trim();
    var msg   = document.getElementById('b-msg').value.trim();
    var errEl = document.getElementById('booking-error');
    errEl.style.display = 'none';

    if (!selectedDate) { errEl.textContent = 'Please select a date.'; errEl.style.display='block'; return; }
    if (!selectedSlot) { errEl.textContent = 'Please select a time slot.'; errEl.style.display='block'; return; }
    if (!name)         { errEl.textContent = 'Please enter your name.'; errEl.style.display='block'; return; }
    if (!email || !/^[^@]+@[^@]+\.[^@]+$/.test(email)) { errEl.textContent = 'Please enter a valid email.'; errEl.style.display='block'; return; }
    if (!/^\d{10}$/.test(phone)) { errEl.textContent = 'Phone must be a 10-digit number.'; errEl.style.display='block'; return; }

    var btn = document.getElementById('confirm-btn');
    btn.textContent = 'Booking...';
    btn.disabled = true;

    var fd = new FormData();
    fd.append('action', 'gaa_book');
    fd.append('nonce',  gaaData.nonce);
    fd.append('name',   name);
    fd.append('email',  email);
    fd.append('phone',  phone);
    fd.append('message', msg);
    fd.append('date',   fmtVal(selectedDate));
    fd.append('slot',   selectedSlot);

    fetch(gaaData.ajaxUrl, { method: 'POST', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(data) {
        if (data.success) {
          document.getElementById('step-date').style.display = 'none';
          document.getElementById('step-slot').style.display = 'none';
          document.getElementById('step-details').style.display = 'none';
          document.getElementById('step-confirmed').classList.add('active');
          document.getElementById('confirm-msg').textContent = 'Hi ' + name + ', your call with Prakash is booked for ' + fmtDisplay(selectedDate) + ' at ' + selectedSlot + ' IST.';
        } else {
          errEl.textContent = data.data.error || 'Something went wrong. Please try again.';
          errEl.style.display = 'block';
          btn.textContent = 'Confirm Booking';
          btn.disabled = false;
        }
      })
      .catch(function() {
        errEl.textContent = 'Network error. Please try again.';
        errEl.style.display = 'block';
        btn.textContent = 'Confirm Booking';
        btn.disabled = false;
      });
  };
})();
</script>

<?php get_footer(); ?>
