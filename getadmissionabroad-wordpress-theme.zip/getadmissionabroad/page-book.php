<?php
/**
 * Template Name: Book a Session
 * Template for: /book
 */
get_header();
?>

<section class="page-hero" style="min-height:auto;padding:2.5rem 0;">
  <div class="container">
    <h1>Book a Free Call with <span class="gold">Prakash</span></h1>
    <p>15 minutes. Prakash listens to your profile and goals — and tells you honestly whether and how he can help.</p>
    <p style="margin-top:0.75rem;font-size:0.9rem;color:#d1d5db;font-style:italic;">This is a fit assessment, not a consulting session. Genuine questions get honest answers.</p>
  </div>
</section>

<section class="section bg-gray">
  <div class="container">
    <div style="max-width:760px;margin:0 auto;background:#fff;border-radius:1.5rem;border:1px solid #f3f4f6;box-shadow:0 2px 12px rgba(0,0,0,0.05);padding:2.5rem;">

      <!-- Step 1: Select Date -->
      <div id="step-date">
        <h2 class="booking-section-title">1. Select a Date</h2>
        <div id="date-picker"></div>
      </div>

      <!-- Step 2: Select Slot (shown after date selected) -->
      <div id="step-slot" class="booking-step">
        <h2 class="booking-section-title" id="slot-heading">2. Select a Time Slot</h2>
        <div class="slot-grid" id="slot-grid"></div>
      </div>

      <!-- Step 3: Personal Details (shown after slot selected) -->
      <div id="step-details" class="booking-step">
        <h2 class="booking-section-title">3. Your Details</h2>
        <div class="form-grid-2">
          <div class="form-group">
            <label class="form-label" for="b-name">Full Name *</label>
            <input class="form-input" type="text" id="b-name" placeholder="e.g. Riya Sharma" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="b-email">Email Address *</label>
            <input class="form-input" type="email" id="b-email" placeholder="e.g. riya@email.com" required>
          </div>
          <div class="form-group">
            <label class="form-label" for="b-phone">Phone Number (10 digits) *</label>
            <input class="form-input" type="tel" id="b-phone" placeholder="e.g. 9876543210" maxlength="10" required>
          </div>

          <!-- Screening: What are you targeting? -->
          <div class="form-group">
            <label class="form-label" for="b-targeting">What are you targeting? *</label>
            <select class="form-input form-select" id="b-targeting" required>
              <option value="">— Select —</option>
              <option value="Undergraduate (UG)">Undergraduate (UG)</option>
              <option value="Postgraduate / Masters (PG)">Postgraduate / Masters (PG)</option>
              <option value="PhD / Research">PhD / Research</option>
              <option value="Other">Other</option>
              <option value="Not sure yet">Not sure yet</option>
            </select>
          </div>

          <!-- Screening: Countries -->
          <div class="form-group" style="grid-column:1/-1;">
            <label class="form-label">Which countries are you considering? *</label>
            <div style="display:flex;flex-wrap:wrap;gap:0.625rem;margin-top:0.375rem;">
              <?php
              $countries = [
                'United States 🇺🇸','United Kingdom 🇬🇧','Canada 🇨🇦',
                'Australia 🇦🇺','UAE 🇦🇪','Other','Not decided',
              ];
              foreach ($countries as $c) {
                $id = 'bc-' . sanitize_title($c);
                ?>
                <label style="display:flex;align-items:center;gap:0.375rem;font-size:0.875rem;cursor:pointer;padding:0.375rem 0.75rem;border:1.5px solid #e5e7eb;border-radius:8px;background:#f9fafb;transition:border-color 0.2s,background 0.2s;" class="country-checkbox-label">
                  <input type="checkbox" class="b-country" value="<?php echo esc_attr($c); ?>" style="accent-color:#1a2744;width:14px;height:14px;flex-shrink:0;">
                  <?php echo esc_html($c); ?>
                </label>
              <?php } ?>
            </div>
          </div>

          <!-- Screening: Timeline -->
          <div class="form-group">
            <label class="form-label" for="b-timeline">When are you looking to apply? *</label>
            <select class="form-input form-select" id="b-timeline" required>
              <option value="">— Select —</option>
              <option value="Within 3 months">Within 3 months</option>
              <option value="3–6 months from now">3–6 months from now</option>
              <option value="6–12 months from now">6–12 months from now</option>
              <option value="12–18 months from now">12–18 months from now</option>
              <option value="Just exploring">Just exploring</option>
            </select>
          </div>

          <!-- Screening: Previous consultant -->
          <div class="form-group">
            <label class="form-label">Have you worked with a study abroad consultant before? *</label>
            <div style="display:flex;flex-direction:column;gap:0.5rem;margin-top:0.375rem;">
              <?php
              $prev = ['No, first time','Yes, but looking for a change','Yes, currently working with one'];
              foreach ($prev as $p) { ?>
                <label style="display:flex;align-items:center;gap:0.5rem;font-size:0.875rem;cursor:pointer;">
                  <input type="radio" name="b-prev-consultant" value="<?php echo esc_attr($p); ?>" style="accent-color:#1a2744;width:15px;height:15px;">
                  <?php echo esc_html($p); ?>
                </label>
              <?php } ?>
            </div>
          </div>

          <!-- Requirement -->
          <div class="form-group" style="grid-column:1/-1;">
            <label class="form-label" for="b-msg">Briefly describe your situation and what you're hoping to get out of this call *</label>
            <textarea class="form-textarea" id="b-msg" rows="3" placeholder="e.g. I'm a final year B.Tech student looking to apply for MS in CS in the US next year." required></textarea>
          </div>
        </div>
        <div id="booking-error" class="form-error" style="display:none;"></div>
        <div id="booking-summary" class="form-summary" style="display:none;"></div>

        <!-- Pre-submit note -->
        <p style="font-size:0.8rem;color:#9ca3af;margin-top:1rem;line-height:1.6;">Prakash personally reviews every booking. You'll hear back on WhatsApp or phone within a few hours to confirm the call.</p>

        <button type="button" id="confirm-btn" onclick="gaaConfirmBooking()" class="btn btn-gold btn-lg" style="width:100%;justify-content:center;margin-top:0.75rem;">
          Confirm Booking
        </button>
      </div>

      <!-- Confirmation screen -->
      <div id="step-confirmed" class="booking-step">
        <div class="form-success" style="padding:3rem 2rem;">
          <span class="check-big">✅</span>
          <h3>Booking Confirmed!</h3>
          <p id="confirm-msg" style="margin-top:0.5rem;"></p>
          <p style="margin-top:1rem;font-size:0.8rem;color:#6b7280;">Thanks for booking. Prakash will review your details and reach out on WhatsApp/phone before the call.</p>
          <a href="mailto:getadmissionabroad.in@gmail.com" class="btn btn-navy" style="margin-top:1.5rem;">✉️ Email Prakash</a>
        </div>
      </div>

    </div>
  </div>
</section>

<script>
(function() {
  var DAY_NAMES   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  var MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December'];

  // Generate time slots 10:00 AM – 8:30 PM
  var TIME_SLOTS = [];
  for (var h = 10; h <= 20; h++) {
    ['00','30'].forEach(function(m) {
      var h12  = h > 12 ? h - 12 : h;
      var ampm = h >= 12 ? 'PM' : 'AM';
      TIME_SLOTS.push((h12 < 10 ? '0' : '') + h12 + ':' + m + ' ' + ampm);
    });
  }

  // Generate next 30 days (skip Sundays)
  var DATES = [];
  var today = new Date(); today.setHours(0,0,0,0);
  for (var i = 1; i <= 30; i++) {
    var d = new Date(today); d.setDate(today.getDate() + i);
    if (d.getDay() !== 0) DATES.push(d);
  }

  function fmtVal(d) {
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  }
  function fmtDisplay(d) {
    return DAY_NAMES[d.getDay()] + ', ' + d.getDate() + ' ' + MONTH_NAMES[d.getMonth()] + ' ' + d.getFullYear();
  }

  function refreshBookingNonce() {
    var fd = new FormData();
    fd.append('action', 'gaa_booking_nonce');
    return fetch(gaaData.ajaxUrl, { method: 'POST', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(data) {
        if (data && data.success && data.data && data.data.nonce) {
          bookingNonce = data.data.nonce;
          return bookingNonce;
        }
        throw new Error('Unable to refresh nonce');
      });
  }

  var selectedDate = null;
  var selectedSlot = '';
  var bookingNonce = (window.gaaData && window.gaaData.nonce) ? window.gaaData.nonce : '';

  // Build date picker
  var picker = document.getElementById('date-picker');
  var groups = {};
  DATES.forEach(function(d) {
    var key = MONTH_NAMES[d.getMonth()] + ' ' + d.getFullYear();
    if (!groups[key]) groups[key] = [];
    groups[key].push(d);
  });
  Object.keys(groups).forEach(function(month) {
    var label = document.createElement('p');
    label.className = 'date-month-label';
    label.textContent = month;
    picker.appendChild(label);

    var grid = document.createElement('div');
    grid.className = 'date-grid';
    groups[month].forEach(function(d) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'date-btn';
      btn.dataset.val = fmtVal(d);
      btn.innerHTML = '<span>' + DAY_NAMES[d.getDay()] + '</span><span class="day-num">' + d.getDate() + '</span>';
      btn.addEventListener('click', function() {
        document.querySelectorAll('.date-btn').forEach(function(b){ b.classList.remove('selected'); });
        btn.classList.add('selected');
        selectedDate = d;
        selectedSlot = '';
        buildSlots(d);
        document.getElementById('step-slot').classList.add('active');
        document.getElementById('step-details').classList.remove('active');
        document.getElementById('slot-heading').textContent = '2. Select a Time Slot — ' + fmtDisplay(d);
        document.querySelectorAll('.slot-btn').forEach(function(s){ s.classList.remove('selected'); });
        document.getElementById('booking-summary').style.display = 'none';
      });
      grid.appendChild(btn);
    });
    picker.appendChild(grid);
  });

  function buildSlots(d) {
    var grid = document.getElementById('slot-grid');
    grid.innerHTML = '';
    TIME_SLOTS.forEach(function(slot) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'slot-btn';
      btn.textContent = slot;
      btn.addEventListener('click', function() {
        document.querySelectorAll('.slot-btn').forEach(function(b){ b.classList.remove('selected'); });
        btn.classList.add('selected');
        selectedSlot = slot;
        document.getElementById('step-details').classList.add('active');
        var summary = document.getElementById('booking-summary');
        summary.style.display = 'block';
        summary.innerHTML = '<strong>Booking Summary:</strong> ' + fmtDisplay(selectedDate) + ' at ' + selectedSlot + ' IST';
      });
      grid.appendChild(btn);
    });
  }

  function submitBooking() {
    var name       = document.getElementById('b-name').value.trim();
    var email      = document.getElementById('b-email').value.trim();
    var phone      = document.getElementById('b-phone').value.trim();
    var targeting  = document.getElementById('b-targeting').value;
    var timeline   = document.getElementById('b-timeline').value;
    var prevRadio  = document.querySelector('input[name="b-prev-consultant"]:checked');
    var prevVal    = prevRadio ? prevRadio.value : '';
    var msg        = document.getElementById('b-msg').value.trim();
    var errEl      = document.getElementById('booking-error');
    errEl.style.display = 'none';

    // Collect countries
    var countries = [];
    document.querySelectorAll('.b-country:checked').forEach(function(cb){ countries.push(cb.value); });

    if (!selectedDate) { errEl.textContent = 'Please select a date.'; errEl.style.display='block'; return; }
    if (!selectedSlot) { errEl.textContent = 'Please select a time slot.'; errEl.style.display='block'; return; }
    if (!name)         { errEl.textContent = 'Please enter your name.'; errEl.style.display='block'; return; }
    if (!email || !/^[^@]+@[^@]+\.[^@]+$/.test(email)) { errEl.textContent = 'Please enter a valid email.'; errEl.style.display='block'; return; }
    if (!/^\d{10}$/.test(phone)) { errEl.textContent = 'Phone must be a 10-digit number.'; errEl.style.display='block'; return; }
    if (!targeting)    { errEl.textContent = 'Please select what you are targeting.'; errEl.style.display='block'; return; }
    if (!countries.length) { errEl.textContent = 'Please select at least one country.'; errEl.style.display='block'; return; }
    if (!timeline)     { errEl.textContent = 'Please select your application timeline.'; errEl.style.display='block'; return; }
    if (!prevVal)      { errEl.textContent = 'Please answer the consultant question.'; errEl.style.display='block'; return; }

    // Append screening answers to message
    var fullMsg = 'Targeting: ' + targeting + '\n'
                + 'Countries: ' + countries.join(', ') + '\n'
                + 'Timeline: ' + timeline + '\n'
                + 'Previous consultant: ' + prevVal + '\n\n'
                + (msg || '(No additional details)');

    var btn = document.getElementById('confirm-btn');
    btn.textContent = 'Booking...';
    btn.disabled = true;

    var fd = new FormData();
    fd.append('action', 'gaa_book');
    fd.append('nonce',  bookingNonce);
    fd.append('name',   name);
    fd.append('email',  email);
    fd.append('phone',  phone);
    fd.append('message', fullMsg);
    fd.append('date',   fmtVal(selectedDate));
    fd.append('slot',   selectedSlot);

    fetch(gaaData.ajaxUrl, { method: 'POST', body: fd })
      .then(function(r){ return r.json(); })
      .then(function(data) {
        if (data.success) {
          document.getElementById('step-date').style.display = 'none';
          document.getElementById('step-slot').style.display = 'none';
          document.getElementById('step-details').style.display = 'none';
          document.getElementById('step-confirmed').classList.add('active');
          document.getElementById('confirm-msg').textContent = 'Hi ' + name + ', your call with Prakash is booked for ' + fmtDisplay(selectedDate) + ' at ' + selectedSlot + ' IST.';
        } else if (data.data && data.data.error === 'Security check failed. Please refresh and try again.') {
          return refreshBookingNonce().then(function() {
            return submitBooking();
          }).catch(function() {
            errEl.textContent = 'Session expired. Please refresh and try again.';
            errEl.style.display = 'block';
            btn.textContent = 'Confirm Booking';
            btn.disabled = false;
          });
        } else {
          errEl.textContent = (data.data && data.data.error) ? data.data.error : 'Something went wrong. Please try again.';
          errEl.style.display = 'block';
          btn.textContent = 'Confirm Booking';
          btn.disabled = false;
        }
      })
      .catch(function() {
        errEl.textContent = 'Network error. Please try again.';
        errEl.style.display = 'block';
        btn.textContent = 'Confirm Booking';
        btn.disabled = false;
      });
  }

  window.gaaConfirmBooking = function() {
    submitBooking();
  };
})();
</script>

<?php get_footer(); ?>
