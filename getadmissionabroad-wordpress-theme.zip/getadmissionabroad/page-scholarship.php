<?php
/**
 * Template Name: Scholarship Guidance
 * Template for: /scholarship
 */
get_header();
$book_url = esc_url(home_url('/book'));
?>
<section class="page-hero"><div class="container"><h1>Scholarship Guidance</h1><p>Essay and positioning support for scholarship applications.</p></div></section>
<section class="section bg-white"><div class="container"><div class="two-col"><div><h2>Scholarship support includes</h2><ul style="margin-top:1rem;display:flex;flex-direction:column;gap:0.65rem;"><?php foreach (['Scholarship essay structuring and review','Motivation and impact narrative support','Program-specific tailoring','Final review for clarity and coherence'] as $item): ?><li style="display:flex;gap:0.5rem;"><span class="check-gold">✓</span><?php echo esc_html($item); ?></li><?php endforeach; ?></ul></div><div class="card card-amber" style="align-self:start;"><h3>Important</h3><p style="color:#4b5563;">We do not guarantee scholarships or funding outcomes.</p></div></div></div></section>
<section class="cta-section"><div class="container" style="text-align:center;"><h2>Work on your scholarship essays</h2><div class="cta-buttons"><a href="<?php echo $book_url; ?>" class="btn btn-gold btn-lg">Book a Free Call</a><a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-outline-white btn-lg">Contact Us</a></div></div></section>
<?php get_footer(); ?>
